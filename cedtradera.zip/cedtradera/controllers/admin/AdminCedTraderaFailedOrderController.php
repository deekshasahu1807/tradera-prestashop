<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedTradera
 */

include_once  _PS_MODULE_DIR_.'cedtradera/classes/CedTraderaOrder.php';
include_once  _PS_MODULE_DIR_.'cedtradera/classes/CedTraderaHelper.php';

class AdminCedTraderaFailedOrderController extends ModuleAdminController
{
	public function __construct()
	{
		$this->db = Db::getInstance();
        $this->bootstrap  = true;
        $this->table = 'cedtradera_order_error';
        $this->identifier = 'id';
        $this->list_no_link = true;
        $this->addRowAction('cancel');

        $this->fields_list = array(
            'id'       => array(
                'title' => 'ID',
                'type'  => 'text',
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ),
            'merchant_sku'     => array(
                'title' => 'SKU',
                'type'  => 'text',
            ),
            'tradera_order_id' => array(
                'title' => 'Tradera Order Id',
                'type'  => 'text',
            ),
            'reason' => array(
                'title' => 'Reason',
                'type'  => 'text',
            ),
        );
        
        parent::__construct();
	}
}
