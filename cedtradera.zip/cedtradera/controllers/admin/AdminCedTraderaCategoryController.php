<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedTradera
 */

require_once _PS_MODULE_DIR_ . 'cedtradera/classes/CedTraderaCategory.php';

class AdminCedTraderaCategoryController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap  = true;
        $this->table      = 'cedtradera_category';
        $this->identifier = 'category_id';
        $this->list_no_link = true;
        //$this->addRowAction('mapcategory');
        $this->fields_list = array(
            'category_id'       => array(
                'title' => 'Category ID',
                'type'  => 'text',
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ),
            'category_name'     => array(
                'title' => 'Category Name',
                'type'  => 'text',
            ),
        );
        parent::__construct();
    }

    public function initToolbar()
    {
        $this->toolbar_btn['export'] = array(
            'href' => self::$currentIndex.'&export'.$this->table.'&token='.$this->token,
            'desc' => $this->l('Export')
        );
    }

    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
            $this->page_header_toolbar_btn['fetch_category'] = array(
                'href' => self::$currentIndex.'&fetchCategory&token='.$this->token,
                'desc' => 'Fetch Category',
                'icon' => 'process-icon-new'
            );
        }
        parent::initPageHeaderToolbar();
    }
    public function renderList()
    {
    	if (Tools::getIsset('fetchCategory')) {
    		$cedtraderaHelper = new CedTraderaHelper();
            // $fetchCategory = "<soap:Body>";
            // $fetchCategory .= "<GetCategories xmlns='http://api.tradera.com' />";
            // $fetchCategory .= "</soap:Body>";
    		$category_data = $cedtraderaHelper->getCategories();
            $myArray = json_decode(json_encode($category_data), true);
            // echo "<pre>"; print_r($myArray);die('ok');

    		if (isset($myArray['result']['Category']) && is_array($myArray['result']['Category']) && $myArray['result']['Category']) 
            {
    			$response = $myArray['result']['Category'];
                foreach($response as $value) 
                {
                   $my_category = $this->setCategories($value); 
                   // echo "<pre>";print_r($my_category);die;
                }
    			// $arrayOfCategory = $response['GetCategoriesResult'];
                
    			// if(isset($arrayOfCategory) && is_array($arrayOfCategory))
       //          {
       //              // echo '<pre>'; print_r($arrayOfCategory); die;
       //              $this->saveCategory($arrayOfCategory);
    			// }
    		}
    	}
    	return parent::renderList();
    }

    public function setCategories($category_array){
        $cat_id = '';
        $cat_name = '';
        $db = Db::getInstance();
        if(isset($category_array['Id']) && isset($category_array['Name']))
        {
            $category_id = $category_array['Id'];
            $category_name = $category_array['Name'];

            $select_category = $db->executeS("SELECT * FROM `"._DB_PREFIX_."cedtradera_category` WHERE category_id ='".$category_id."'");
// echo "<pre>";print_r($select_category);die;
            if(empty($select_category) && $category_id != 0)
            {
                $db->insert(
                    'cedtradera_category', 
                    array(
                        'category_id' => (int)$category_id,
                        'category_name' => pSQL($category_name),
                        'parent_id' => (int) '0'
                    )
                );
            }
            if(isset($category_array['Category']) && is_array($category_array['Category']) && $category_array['Category'])
            {
                $response = $this->childCategory($category_array['Category'], $category_name, $category_id); 
            }
        }
       
        //echo '<pre>'; print_r($response);die;
    }

    public function childCategory($cat_array = array(), $parent_cat = '', $parent_cat_id = '')
    {
        // echo '<pre>'; print_r($cat_array);die;
        $response = array();
        $db = Db::getInstance();

        foreach($cat_array as $value)
        {
            $cat_id = $value['Id'];
            $cat_name = $parent_cat . ' > ' . $value['Name'] . '<br/>';
            $response[$cat_id] =  $cat_name;
            // echo "<pre>";print_r($cat_name);die;
            if(isset($value['Category']) && is_array($value['Category']) && $value['Category'])
            {
                // $cat_name
                $this->childCategory($value['Category'], $cat_name, $cat_id);
            }
            //$response[] = $cat_name;
            $select_category = $db->executeS("SELECT * FROM `"._DB_PREFIX_."cedtradera_category` WHERE category_id ='".$cat_id."'");

            if(empty($select_category) && $cat_id != 0)
            {
                $db->insert(
                    'cedtradera_category', 
                    array(
                        'category_id' => (int)$cat_id,
                        'category_name' => pSQL($cat_name),
                        'parent_id' => (int)$parent_cat_id
                    )
                );
            }
           //echo '<pre>'; print_r($cat_name);
        }
        
        return true;

    }

    public function saveCategory($arrayOfCategory = array())
    {
        foreach($arrayOfCategory as $key => $firstArrayCategories)
        {
            $first_count = '0';
            $category_name = '';
            foreach($firstArrayCategories as $firstKey => $firstArrayCategory)
            {
                //echo $firstKey;
                //echo '<pre>'; print_r($firstArrayCategory);
                if($firstKey === $first_count.'_attr' && !isset($firstArrayCategory['Category'])) 
                {
                    if (empty($category_name)) {
                        $category_name = $firstArrayCategory['Name'];
                    } else {
                        $category_name = $category_name . ' > ' . $firstArrayCategory['Name'];
                    }
                    $this->addCategory($firstArrayCategory, $category_name);
                    
                } else if(isset($firstArrayCategory['Category']) && is_array($firstArrayCategory['Category'])) {
                        $this->saveCategory($firstArrayCategory);
                } 
                else {
                    if (empty($category_name)) {
                        $category_name = $firstArrayCategory['Name'];
                    } else {
                        $category_name = $category_name . ' > ' . $firstArrayCategory['Name'];
                    }
                    $this->addCategory($firstArrayCategory, $category_name);
                }
                $first_count++;  
            } 
            //die;
        } 
    }

    public function addCategory($category_data, $category_name = '')
    {
        $db = Db::getInstance();
        if(!empty($category_data))
        {
            if(!empty($category_name))
                $category_name = $category_name;
            else
                $category_name = $category_data['Name'];
            
            $db->insert(
                'cedtradera_category', 
                array(
                    'category_id' => (int)$category_data['Id'],
                    'category_name' => pSQL($category_name)
                )
            );
        }
    }

    // public function addCategory($category_array = array())
    // {
    //   $db = Db::getInstance();
    //   if(isset($category_array['Category']) && is_array($category_array['Category']) && !empty($category_array['Category'])) 
    //   {
    //   	foreach ($category_array as $index => $categories) 
    //   	{
    //   		echo '<pre>'; print_r($categories); die; 
    //   		$count = '0';
    //   		foreach($categories as $key => $category)
    //   		{
    //   			if(isset($category['Category']) && is_array($category['Category']) && !empty($category['Category']) && !($key != $count . '_attr')) 
		  //     	{
		  //     		$result = $this->addCategory($category);
		  //     	} else {
		  //     		if($count . '_attr' == $key && is_array($category) && !empty($category))
		  //     		{
		  //     			$attribute_id = $category['Id'];
		  //     			$attribute_name = $category['Name'];
		  //     			$category_id = $category[$count]['Id'];
		  //     			$result = $db->insert(
		  //     				'cedtradera_attribute', 
		  //     				array(
		  //     					'attribute_id' => $attribute_id,
		  //     					'attribute_name' => $attribute_name,
		  //     					'category_id' => $category_id,
		  //     					)
		  //     			);
		  //     		} else if(is_array($category) && !empty($category)) {
		  //     			if(isset($category['Category']) && !isset($category['Category_attr'])) 
		  //     			{
			 //      			// echo '<pre>'; print_r($category);
			 //      			$category_id = $category['Category']['Id'];
			 //      			$category_name = $category['Category']['Name'];
			 //      			$attribute_id = $category['Category_attr']['Id'];
			 //      			$attribute_name = $category['Category_attr']['Name'];
			 //      			$result = $db->insert(
			 //      				'cedtradera_category', 
			 //      				array(
			 //      					'category_id' => $category_id,
			 //      					'category_name' => $category_name
			 //      				)
			 //      			);

			 //      			$attribute_result = $db->insert(
			 //      				'cedtradera_attribute', 
			 //      				array(
			 //      					'attribute_id' => $attribute_id,
			 //      					'attribute_name' => $attribute_name,
			 //      					'category_id' => $category_id,
			 //      					)
			 //      				);
			 //      		} else {
			 //      			// echo '<pre>'; print_r($category);
			 //      			try {
			 //      				$category_id = $category['Id'];
			 //      			    $category_name = $category['Name'];
			 //      			} catch(Exception $e){
			 //      				$cedTraderaHelper = new CedTraderaHelper();
			 //      				$cedTraderaHelper->log(
				// 	                'CedTraderaCategory:: fetchCategory',
				// 	                'Exception',
				// 	                $e->getMessage(),
				// 	                $e->getMessage(),
				// 	                true
				// 	            );
				// 	            return array('success' => false, 'message' => $e->getMessage());
			 //      			}
			 //      			$result = $db->insert(
			 //      				'cedtradera_category', 
			 //      				array(
			 //      					'category_id' => $category_id,
			 //      					'category_name' => $category_name
			 //      				)
			 //      			);
			 //      		}
		  //     		}
		  //     	}
		  //     	$count++;
    //   		}
	      	
	   //  } 
    //   }
    // }
    // public function addChildCategoryCategory($categories = array())
    // {
    // 	$db = Db::getInstance();
    // 	if(isset($categories['Category']) && is_array($categories['Category']) && !empty($categories['Category'])){
    // 		$count = '0';
    // 		foreach($categories['Category'] as $key => $category){
    // 			if(isset($category['Category']) && is_array($category['Category']) && !empty($category['Category'])) 
		  //     	{
		  //     		$result = $this->addChildCategoryCategory($category);
		  //     	} else {
		  //     		if($count . '_attr' == $key && is_array($category) && !empty($category))
		  //     		{
		  //     			$attribute_id = $category['Id'];
		  //     			$attribute_name = $category['Name'];
		  //     			$category_id = $category[$count]['Id'];
		  //     			$result = $db->insert(
		  //     				'cedtradera_attribute', 
		  //     				array(
		  //     					'attribute_id' => $attribute_id,
		  //     					'attribute_name' => $attribute_name,
		  //     					'category_id' => $category_id,
		  //     					)
		  //     				);
		  //     		} else if(is_array($category) && !empty($category)) {
		  //     			$category_id = $category['Id'];
		  //     			$category_name = $category['Name'];
		  //     			$result = $db->insert(
		  //     				'cedtradera_category', 
		  //     				array(
		  //     					'category_id' => $category_id,
		  //     					'category_name' => $category_name
		  //     				)
		  //     			);
		  //     		}
		  //     	}
		  //     	$count++;
    // 		}
    // 	}
    // }
}