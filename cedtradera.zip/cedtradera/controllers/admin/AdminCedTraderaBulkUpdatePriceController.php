<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedTradera
 */

include_once  _PS_MODULE_DIR_.'cedtradera/classes/CedTraderaHelper.php';
include_once  _PS_MODULE_DIR_.'cedtradera/classes/CedTraderaProduct.php';
// include_once  _PS_MODULE_DIR_.'cedtradera/classes/CedTraderaFeeds.php';

class AdminCedTraderaBulkUpdatePriceController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function ajaxProcessUpdatePrice()
    {
        $value = Tools::getAllValues();
        $failedArray = array();
        $successArray = array();
        $CedTraderaHelper = new CedTraderaHelper;
        $CedTraderaProduct = new CedTraderaProduct;
        try {
            $product_ids = array();
            if (isset($value['selected'])) {
                $product_ids = $value['selected'];
            }
            $productToUpdatePrice = '';
            if (is_array($product_ids) && count($product_ids)) {
                // $product_ids = array_chunk($product_ids, '100');
                $productToUpdatePrice .= "<soap:Body>";
                $productToUpdatePrice .= "<SetPriceOnShopItems xmlns='http://api.tradera.com'>";
                $productToUpdatePrice .= "<request>";
                $productToUpdatePrice .= "<ShopItems>";

                foreach ($product_ids as $product_id) 
                {
                    $tradera_item_id = $CedTraderaProduct->getTraderaItemId($product_id);
                    $tradera_item_id = isset($tradera_item_id) ? $tradera_item_id : '0';
                   
                    if (!empty($tradera_item_id)) 
                    {
                        $successArray[] = $product_id;
                        $price = $CedTraderaProduct->getCedTraderaPrice($product_id, array());
                        $productToUpdatePrice .= "<SetPriceShopItem>";
                          $productToUpdatePrice .= "<Id>";
                          $productToUpdatePrice .= $tradera_item_id;
                          $productToUpdatePrice .= "</Id>";
                          $productToUpdatePrice .= "<Price>";
                          $productToUpdatePrice .= $price;
                          $productToUpdatePrice .= "</Price>";
                          $productToUpdatePrice .= "<SetPriceShopItem>";
                    } else {
                        $failedArray[] = $product_id;
                    }
                }

                $productToUpdatePrice .= "</ShopItems>";
                $productToUpdatePrice .= "</request>";
                $productToUpdatePrice .= "</SetPriceOnShopItems>";
                $productToUpdatePrice .= "</soap:Body>";
                $requestSent = $CedTraderaHelper->traderaPostRequest('/v3/RestrictedService.asmx', 'SetQuantityOnShopItems', $productToUpdatePrice);
                if (isset($requestSent['item_id'])) 
                {
                    if(!empty($requestSent['msg']))
                        $message = $requestSent['msg'];
                    else
                        $message = ' Price Updated Successfully';
                    die(Tools::jsonEncode(array(
                        'success' => true,
                        'message' => 'Product Id : ' . implode(',', $successArray) . $message
                    )));
                } else {
                    if(!empty($requestSent['msg']))
                        $message = $requestSent['msg'];
                    else
                        $message = ' Price Updation failed Item id not Found.';
                    die(Tools::jsonEncode(array(
                        'success' => false,
                        'message' => 'Product Id : ' . implode(',', $failedArray) . $message
                    )));
                }
            }
        } catch(\Exception $e) {
            $CedTraderaHelper->log(
                'AdminCedTraderaBulkUpdatePriceController::updatePrice',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            die(Tools::jsonEncode(array(
                'success' => true,
                'message' => $e->getMessage()
            )));
        }
    }

    public function initContent()
    {
        parent::initContent();
        $db = Db::getInstance();
        $productIds = array();
        $res = $db->executeS("SELECT `product_id` FROM `"._DB_PREFIX_."cedtradera_profile_products`");
        if (isset($res) && !empty($res) && is_array($res)) {
            foreach ($res as $id) {
                $productIds[] = $id['product_id'];
            }
        }
        if (!empty($productIds)) {
            $productIds = array_unique($productIds);
        }
        $link = new LinkCore();
        $controllerLink = $link->getAdminLink('AdminCedTraderaBulkUpdatePrice');
        $this->context->smarty->assign(array('controller_link' => $controllerLink));
        $this->context->smarty->assign(array('token' => $this->token));
        $this->context->smarty->assign(array('ids_array' => (json_encode($productIds))));
        $content = $this->context->smarty
            ->fetch(_PS_MODULE_DIR_ . 'cedtradera/views/templates/admin/product/updatePrice.tpl');
        $this->context->smarty->assign(array(
            'content' => $this->content . $content
        ));
    }
}
