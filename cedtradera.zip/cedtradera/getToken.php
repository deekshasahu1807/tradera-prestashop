<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedTradera
 */

include(dirname(__FILE__).'/../../config/config.inc.php');
include_once(_PS_MODULE_DIR_.'cedtradera/classes/CedTraderaHelper.php');

// var_dump(Tools::getValue('secure_key'));die;
if(strpos(Tools::getValue('secure_key'), '?') !== false)
{
    $secure_key_data = explode('?',Tools::getValue('secure_key'));
     $secure_key = $secure_key_data[0];
} else {
    $secure_key = Tools::getValue('secure_key');
}

if (!Tools::getIsset('secure_key')
 || $secure_key != Configuration::get('CEDTRADERA_CRON_SECURE_KEY')) {
    die('Secure key does not matched');
}

try {
    $token = '';
    $expire = '';
    $CedTraderaHelper = new CedTraderaHelper();

    if(Tools::getIsset('token') && Tools::getValue('token') && Tools::getIsset('exp') && Tools::getValue('exp'))
    {
        $token = Tools::getValue('token');
        $expire = Tools::getValue('exp');

        Configuration::updateValue('CEDTRADERA_API_ACCESS_TOKEN', $token);
        Configuration::updateValue('CEDTRADERA_ACCESS_EXPIRY', $expire);

        $CedTraderaHelper->log(
            'CronGetToken',
            'Info',
            'Cron For Get Token',
            Tools::jsonEncode(
            Tools::getAllValues()
            ),
            true
        );
        die(Tools::jsonEncode(array(
        'success' => true,
        'message' => 'Token '. $token .' fetched successfully with expire '. $expire
    )));
    } else {
        die(Tools::jsonEncode(array(
        'success' => false,
        'message' => 'Something went wrong while fetching token'
    )));
    }
    
    
} catch (Exception $e) {
    $CedTraderaHelper->log(
        'CronGetToken',
        'Exception',
        $e->getMessage(),
        Tools::jsonEncode(
            array(
                'Trace' => $e->getTraceAsString()
            )
        ),
        true
    );
    die(Tools::jsonEncode(array(
        'success' => false,
        'message' => $e->getMessage()
        )));
}
