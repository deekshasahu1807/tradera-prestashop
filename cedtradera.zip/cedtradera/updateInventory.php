<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedTradera
 */

include(dirname(__FILE__).'/../../config/config.inc.php');
include_once _PS_MODULE_DIR_ . 'cedtradera/classes/CedTraderaHelper.php';
include_once(_PS_MODULE_DIR_.'cedtradera/classes/CedTraderaProduct.php');
/*include_once(_PS_MODULE_DIR_.'cedwish/classes/CedTraderaFeeds.php');*/


if (!Tools::isSubmit('secure_key')
 || Tools::getValue('secure_key') != Configuration::get('CEDTRADERA_CRON_SECURE_KEY')) {
    die('Secure key not matched');
}

try {
	    $failedArray = array();
        $successArray = array();
        $CedTraderaHelper = new CedTraderaHelper;
        $CedTraderaProduct = new CedTraderaProduct;
        $db = Db::getInstance();

        $product_ids = array();

	    $res = $db->executeS("SELECT `product_id` FROM `"._DB_PREFIX_."cedtradera_profile_products`");
	    if (isset($res) && !empty($res) && is_array($res)) {
	        foreach ($res as $id) {
	            $product_ids[] = $id['product_id'];
	        }
	    }
	    if (!empty($product_ids)) {
	        $product_ids = array_unique($product_ids);
	    }

        $productToUpdateQuantity = '';
        if (is_array($product_ids) && count($product_ids)) {
            
            // $product_ids = array_chunk($product_ids, '100');

            $productToUpdateQuantity .= "<soap:Body>";
            $productToUpdateQuantity .= "<SetQuantityOnShopItems xmlns='http://api.tradera.com'>";
            $productToUpdateQuantity .= "<request>";
            $productToUpdateQuantity .= "<ShopItems>";

            foreach ($product_ids as $product_id) 
            {
                $tradera_item_id = $CedTraderaProduct->getTraderaItemId($product_id);

                $tradera_item_id = isset($tradera_item_id) ? $tradera_item_id : '0';
               
                if (!empty($tradera_item_id)) 
                {
                    $successArray[] = $product_id;
                    $quantity = $CedTraderaProduct->getCedTraderaQuantity($product_id, array());
                    $productToUpdateQuantity .= "<SetQuantityShopItem>";
                      $productToUpdateQuantity .= "<Id>";
                      $productToUpdateQuantity .= $tradera_item_id;
                      $productToUpdateQuantity .= "</Id>";
                      $productToUpdateQuantity .= "<Quantity>";
                      $productToUpdateQuantity .= $quantity;
                      $productToUpdateQuantity .= "</Quantity>";
                      $productToUpdateQuantity .= "<SetQuantityShopItem>";
                } else {
                    $failedArray[] = $product_id;
                }
            }

            $productToUpdateQuantity .= "</ShopItems>";
            $productToUpdateQuantity .= "</request>";
            $productToUpdateQuantity .= "</SetQuantityOnShopItems>";
            $productToUpdateQuantity .= "</soap:Body>";

            $requestSent = $CedTraderaHelper->traderaPostRequest('/v3/RestrictedService.asmx', 'SetQuantityOnShopItems', $productToUpdateQuantity);
            if (isset($requestSent['item_id'])) 
            {
                if(!empty($requestSent['msg']))
                    $message = $requestSent['msg'];
                else
                    $message = ' Quantity Updated Successfully';
               
                die(Tools::jsonEncode(array(
                    'success' => true,
                    'message' => 'Product Id : ' . implode(',', $successArray) . $message
                )));
            } else {
                if(!empty($requestSent['msg']))
                    $message = $requestSent['msg'];
                else
                    $message = ' Quantity Update failed Item id not Found.';
                die(Tools::jsonEncode(array(
                    'success' => false,
                    'message' => 'Product Id : ' . implode(',', $failedArray) . $message
                )));
            }
        }
    } catch(\Exception $e) {
        $CedTraderaHelper->log(
            'AdminCedTraderaBulkUpdateInventoryController::updateStock',
            'Exception',
            $e->getMessage(),
            $e->getMessage(),
            true
        );
        die(Tools::jsonEncode(array(
            'success' => true,
            'message' => $e->getMessage()
        )));
    }