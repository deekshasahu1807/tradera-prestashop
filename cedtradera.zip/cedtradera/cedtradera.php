<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedTradera
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
if (!function_exists('curl_version')) {
    exit;
}

include_once(_PS_MODULE_DIR_.'cedtradera/classes/CedTraderaHelper.php');
include_once(_PS_MODULE_DIR_.'cedtradera/classes/CedTraderaProduct.php');

class CedTradera extends Module
{
    public $fields_form = array();
    public function __construct()
    {
        $this->name = 'cedtradera';
        $this->tab = 'administration';
        $this->version = '0.0.1';
        $this->author = 'CedCommerce';
        $this->bootstrap = true;
        $this->need_instance = 1;
        $this->module_key = '3912dc2255d08bb8db35a1236856b6e4';

        $this->controllers = array('validation');
        $this->secure_key = Tools::encrypt($this->name);
        $this->is_eu_compatible = 1;
        $this->currencies = false;
        $this->displayName = $this->l('Tradera Integration');
        $this->description = $this->l(
            'Allow merchants to integrate their Prestashop store with Tradera marketplace.'
        );
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        $this->ps_versions_compliancy = array('min' => '1.6.0.0', 'max' => _PS_VERSION_);
        parent::__construct();
    }
    /* install needed modules, tabs and hooks for tradera integration
    *
    */
    public function install()
    {
        require_once  _PS_MODULE_DIR_.'cedtradera/sql/installTables.php';
        if (!parent::install()
            || !$this->installTab('AdminCedTradera', 'Tradera Integration', 0)
            || !$this->installTab(
                'AdminCedTraderaCategory',
                'Tradera Category',
                (int)Tab::getIdFromClassName('AdminCedTradera')
            )
            || !$this->installTab(
                'AdminCedTraderaProfile',
                'Tradera Profile',
                (int)Tab::getIdFromClassName('AdminCedTradera')
            )
            || !$this->installTab(
                'AdminCedTraderaProduct',
                'Tradera Products',
                (int)Tab::getIdFromClassName('AdminCedTradera')
            )
            || !$this->installTab(
                'AdminCedTraderaBulkUploadProduct',
                'Tradera Bulk Upload',
                (int)Tab::getIdFromClassName('AdminCedTradera')
            )
            || !$this->installTab(
                'AdminCedTraderaBulkUpdateInventory',
                'Tradera Update Inventory',
                (int)Tab::getIdFromClassName('AdminCedTradera')
            )
            || !$this->installTab(
                'AdminCedTraderaBulkUpdatePrice',
                'Tradera Update Price',
                (int)Tab::getIdFromClassName('AdminCedTradera')
            )
            || !$this->installTab(
                'AdminCedTraderaFeeds',
                'Tradera Feeds',
                (int)Tab::getIdFromClassName('AdminCedTradera')
            )
            || !$this->installTab(
                'AdminCedTraderaOrder',
                'Tradera Orders',
                (int)Tab::getIdFromClassName('AdminCedTradera')
            )
            || !$this->installTab(
                'AdminCedTraderaFailedOrder',
                'Tradera Failed Orders',
                (int)Tab::getIdFromClassName('AdminCedTradera')
            )
            || !$this->installTab(
                'AdminCedTraderaLogs',
                'Tradera Logs',
                (int)Tab::getIdFromClassName('AdminCedTradera')
            )
            || !$this->installTab(
                'AdminCedTraderaConfig',
                'Tradera Configuration',
                (int)Tab::getIdFromClassName('AdminCedTradera')
            )
            || !$this->registerHook('actionProductUpdate')
            || !$this->registerHook('actionProductDelete')
            || !$this->registerHook('actionUpdateQuantity')
            || !$this->registerHook('actionOrderStatusPostUpdate')
            || !$this->registerHook('displayBackOfficeHeader')
        ) {
            return false;
        }
        if (!Configuration::get('PS_ORDER_RETURN')) {
            Configuration::updateValue('PS_ORDER_RETURN', 1);
        }
        return true;
    }
    // uninstall Tradera tabs and additional modules along with Tradera integration module
    public function uninstall()
    {
        //        foreach ($this->getConfigFormValues() as $key=>$value) {
        //            Configuration::deleteByName($key);
        //        }
        if (!parent::uninstall()
            || !$this->uninstallTab('AdminCedTraderaCategory')
            || !$this->uninstallTab('AdminCedTraderaProfile')
            || !$this->uninstallTab('AdminCedTraderaProduct')
            || !$this->uninstallTab('AdminCedTraderaBulkUploadProduct')
            || !$this->uninstallTab('AdminCedTraderaBulkUpdateInventory')
            || !$this->uninstallTab('AdminCedTraderaBulkUpdatePrice')
            || !$this->uninstallTab('AdminCedTraderaFeeds')
            || !$this->uninstallTab('AdminCedTraderaOrder')
            || !$this->uninstallTab('AdminCedTraderaFailedOrder')
            || !$this->uninstallTab('AdminCedTraderaLogs')
            || !$this->uninstallTab('AdminCedTraderaConfig')
            || !$this->uninstallTab('AdminCedTradera')
            || !$this->unregisterHook('displayBackOfficeHeader')
            || !$this->unregisterHook('actionProductUpdate')
            || !$this->unregisterHook('actionProductDelete')
            || !$this->unregisterHook('actionUpdateQuantity')
            || !$this->unregisterHook('actionOrderStatusPostUpdate')
        ) {
            return false;
        }
        return true;
    }
    /* install tabs on basis of class name given
    * use tab name in frontend
    * install under the parent tab given
    */
    public function installTab($class_name, $tab_name, $parent)
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = $class_name;
        $tab->name = array();
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = $tab_name;
        }
        if ($parent == 0 && _PS_VERSION_ >= '1.7') {
            $tab->id_parent = (int)Tab::getIdFromClassName('SELL');
            $tab->icon = 'CT';
        } else {
            $tab->id_parent = $parent;
        }
        $tab->module = $this->name;
        return $tab->add();
    }
    /**
     * uninstall tabs created by module
     */
    public function uninstallTab($class_name)
    {
        $id_tab = (int)Tab::getIdFromClassName($class_name);
        if ($id_tab) {
            $tab = new Tab($id_tab);
            return $tab->delete();
        } else {
            return false;
        }
    }
    // save and display Configuration settings for Tradera integration
    public function getContent()
    {
        $output = null;
        Configuration::updateValue(
            'CEDTRADERA_ACCEPT_URL',
            Context::getContext()->shop->getBaseURL(true).
            'modules/cedtradera/getToken.php?secure_key=hggcdashj56467'
        );
        Configuration::updateValue(
            'CEDTRADERA_REJECT_URL',
            Context::getContext()->shop->getBaseURL(true).
            'modules/cedtradera/getToken.php?secure_key=hggcdashj56467'
        );
        if (Tools::isSubmit('submitgeneralsetting')) {
            $mode = (string)Tools::getValue('CEDTRADERA_MODE');
            Configuration::updateValue('CEDTRADERA_MODE', $mode);
            if ($mode == 'live') {
                $ced_api_url = trim(Tools::getValue('CEDTRADERA_API_URL_LIVE'));
            } else {
                $ced_api_url = trim(Tools::getValue('CEDTRADERA_API_URL_SANDBOX'));
            }
            $cedtradera_app_id = trim(Tools::getValue('CEDTRADERA_APP_ID'));
            $cedtradera_app_key = trim(Tools::getValue('CEDTRADERA_APP_KEY'));
            $cedtradera_secret_key = trim(Tools::getValue('CEDTRADERA_SECRET_KEY'));
            $cedtradera_user_id = trim(Tools::getValue('CEDTRADERA_USER_ID'));
            $cedtradera_accept_url = trim(Tools::getValue('CEDTRADERA_ACCEPT_URL'));
            $cedtradera_reject_url = trim(Tools::getValue('CEDTRADERA_REJECT_URL'));
            //$cedtradera_code = trim(Tools::getValue('CEDTRADERA_CODE'));
            $cedtradera_token = trim(Tools::getValue('CEDTRADERA_API_ACCESS_TOKEN'));
            $cedtradera_access_expiry = trim(Tools::getValue('CEDTRADERA_ACCESS_EXPIRY'));
            Configuration::updateValue('CEDTRADERA_API_URL', $ced_api_url);
            Configuration::updateValue('CEDTRADERA_APP_ID', $cedtradera_app_id);
            Configuration::updateValue('CEDTRADERA_APP_KEY', $cedtradera_app_key);
            Configuration::updateValue('CEDTRADERA_SECRET_KEY', $cedtradera_secret_key);
            Configuration::updateValue('CEDTRADERA_USER_ID', $cedtradera_user_id);
            Configuration::updateValue('CEDTRADERA_ACCEPT_URL', $cedtradera_accept_url);
            Configuration::updateValue('CEDTRADERA_REJECT_URL', $cedtradera_reject_url);
            //Configuration::updateValue('CEDTRADERA_CODE', $cedtradera_code);
            Configuration::updateValue('CEDTRADERA_API_ACCESS_TOKEN', $cedtradera_token);
            Configuration::updateValue('CEDTRADERA_ACCESS_EXPIRY', $cedtradera_access_expiry);
            if (empty($ced_api_url)
                || empty($cedtradera_app_id)
                || empty($cedtradera_app_key)
                || empty($cedtradera_secret_key)
            ) {
                $output .= $this->displayError($this->l('Invalid Api credentials.'));
            } elseif (Tools::strlen($cedtradera_secret_key) < 32) {
                $output .= $this->displayError(
                    $this->l('The length of Secret Key must be between 32 and 255 characters')
                );
            } elseif (!Validate::isAbsoluteUrl($cedtradera_accept_url)) {
                $output .= $this->displayError($this->l('Accept Url is not valid'));
            } elseif (!Validate::isAbsoluteUrl($cedtradera_reject_url)) {
                $output .= $this->displayError($this->l('Reject Url is not valid'));
            } else {
                Configuration::updateValue('CEDTRADERA_API_URL', $ced_api_url);
                Configuration::updateValue('CEDTRADERA_APP_ID', $cedtradera_app_id);
                Configuration::updateValue('CEDTRADERA_APP_KEY', $cedtradera_app_key);
                Configuration::updateValue('CEDTRADERA_SECRET_KEY', $cedtradera_secret_key);
                Configuration::updateValue('CEDTRADERA_USER_ID', $cedtradera_user_id);
                Configuration::updateValue('CEDTRADERA_ACCEPT_URL', $cedtradera_accept_url);
                Configuration::updateValue('CEDTRADERA_REJECT_URL', $cedtradera_reject_url);
                //Configuration::updateValue('CEDTRADERA_CODE', $cedtradera_code);
                Configuration::updateValue('CEDTRADERA_API_ACCESS_TOKEN', $cedtradera_token);
                Configuration::updateValue('CEDTRADERA_ACCESS_EXPIRY', $cedtradera_access_expiry);
                $output .= $this->displayConfirmation(' General Settings saved successfully.');
            }
        }
        if (Tools::getValue('submit_get_token')) {
            $ced_api_url = trim(Configuration::get('CEDTRADERA_API_URL'));
            $cedtradera_app_id = trim(Configuration::get('CEDTRADERA_APP_ID'));
            $cedtradera_app_key = trim(Configuration::get('CEDTRADERA_APP_KEY'));
            $cedtradera_secret_key = trim(Configuration::get('CEDTRADERA_SECRET_KEY'));
            $cedtradera_user_id = trim(Configuration::get('CEDTRADERA_USER_ID'));
            $cedtradera_accept_url = trim(Configuration::get('CEDTRADERA_ACCEPT_URL'));
            $cedtradera_reject_url = trim(Configuration::get('CEDTRADERA_REJECT_URL'));

            //$cedtradera_code = trim(Configuration::get('CEDTRADERA_CODE'));
            if (empty($ced_api_url)
                || empty($cedtradera_app_id)
                || empty($cedtradera_app_key)
                || empty($cedtradera_secret_key)
                || empty($cedtradera_user_id)
            ) {
                $output .= $this->displayError($this->l('Please fill all the required fields. '));
            } elseif (Tools::strlen($cedtradera_secret_key) < 32) {
                $output .= $this->displayError(
                    $this->l('The length of Secret Key must be between 32 and 255 characters')
                );
            } elseif (!ValidateCore::isAbsoluteUrl($cedtradera_accept_url)) {
                $output .= $this->displayError($this->l('Accept Url is not valid'));
            } elseif (!ValidateCore::isAbsoluteUrl($cedtradera_reject_url)) {
                $output .= $this->displayError($this->l('Reject Url is not valid'));
            } else {
                // $cedTraderaHelper = new CedTraderaHelper();
                // $fetch_token_request = '<soap:Body>';
                // $fetch_token_request .= '<FetchToken xmlns="http://api.tradera.com">';
                // $fetch_token_request .= '<UserId>';
                // $fetch_token_request .= Configuration::get('CEDTRADERA_APP_ID');
                // $fetch_token_request .='</UserId>';
                // $fetch_token_request .= '<secretKey>';
                // $fetch_token_request .= Configuration::get('CEDTRADERA_SECRET_KEY');
                // $fetch_token_request .= '</secretKey>';
                // $fetch_token_request .= '</FetchToken>';
                // $fetch_token_request .= '</soap:Body>';
                
                // $response = $cedTraderaHelper->fetchToken();

                
                
                if (isset($response['success']) && ($response['success'] == true) && isset($response['message'])) {
                    $response = $response['message']['Token'];

                    Configuration::updateValue('CEDTRADERA_API_ACCESS_TOKEN', $response['AuthToken']);
                    Configuration::updateValue('CEDTRADERA_ACCESS_EXPIRY', $response['HardExpirationTime']);
                    $output .= $this->displayConfirmation($response['AuthToken'] . ' Token fetched successfully.');
                } else {
                    $msg = $response['message'] ? $response['message'] : 'Failed to get response from tradera';
                    $output .= $this->displayError($this->l($msg));
                }
            }
        }
        if (!Tools::isSubmit('submitgeneralsetting')
            && !Tools::isSubmit('traderasettings')
        ) {
            $ced_api_url = trim(Configuration::get('CEDTRADERA_API_URL'));
            $cedtradera_app_id = trim(Configuration::get('CEDTRADERA_APP_ID'));
            $cedtradera_app_key = trim(Configuration::get('CEDTRADERA_APP_KEY'));
            $cedtradera_secret_key = trim(Configuration::get('CEDTRADERA_SECRET_KEY'));
            $cedtradera_accept_url = trim(Configuration::get('CEDTRADERA_ACCEPT_URL'));
            $cedtradera_reject_url = trim(Configuration::get('CEDTRADERA_REJECT_URL'));
            //$cedtradera_code = trim(Configuration::get('CEDTRADERA_CODE'));
            $cedtradera_token = trim(Configuration::get('CEDTRADERA_API_ACCESS_TOKEN'));
            $cedtradera_access_expiry = trim(Configuration::get('CEDTRADERA_ACCESS_EXPIRY'));
            if (empty($ced_api_url)
                || empty($cedtradera_app_id)
                || empty($cedtradera_app_key)
                || empty($cedtradera_secret_key)
            ) {
                $output .= $this->displayError($this->l('Please fill all the required fields. '));
            } elseif (Tools::strlen($cedtradera_secret_key) < 32) {
                $output .= $this->displayError(
                    $this->l('The length of Secret Key must be between 32 and 255 characters')
                );
            } elseif (!Validate::isAbsoluteUrl($cedtradera_accept_url)) {
                $output .= $this->displayError($this->l('Accept Url is not a valid url '));
            } elseif (!Validate::isAbsoluteUrl($cedtradera_reject_url)) {
                $output .= $this->displayError($this->l('Reject Url is not a valid url '));
            } elseif (empty($cedtradera_token)) {
                $output .= $this->displayError($this->l('Access Token is missing!'));
            } 
                //else {
            //     $cedTraderaHelper = new CedTraderaHelper();
            //     $response = $cedTraderaHelper->refreshToken();
            //     if (isset($response['success']) && $response['success'] == true) {
            //         $output .= $this->displayConfirmation($response['message'] . ' Token refreshed successfully.');
            //     } else {
            //         $msg = $response['message'] ? $response['message'] : 'Failed to get response from tradera';
            //         $output .= $this->displayError($this->l($msg));
            //     }
            // }
        }
        if (Tools::isSubmit('traderasettings')) {
            $form_values = $this->getConfigFormValues();
            foreach (array_keys($form_values) as $key) {
                if (Tools::getIsset($key)) {
                    $key = trim($key);
                    Configuration::updateValue($key, Tools::getValue($key));
                }
            }
            $price_type = Tools::getValue('CEDTRADERA_PRICE_VARIATION_TYPE');
            $order_email = Tools::getValue('CEDTRADERA_ORDER_EMAIL');
            $customer_id = Tools::getValue('CEDTRADERA_CUSTOMER_ID');
            if (isset($price_type)
                && ($price_type == 'increase_fixed' || $price_type == 'decrease_fixed')) {
                $fixed_price = Tools::getValue('CEDTRADERA_PRICE_VARIATION_FIXED');
                if (empty($fixed_price) || !Validate::isFloat($fixed_price)) {
                    $output .= $this->displayError($this->l('The fixed price should be a valid number'));
                }
            } elseif (isset($price_type)
                && ($price_type == 'increase_per' || $price_type == 'decrease_per')) {
                $fixed_per = Tools::getValue('CEDTRADERA_PRICE_VARIATION_PER');
                if (empty($fixed_per) || !Validate::isFloat($fixed_per)) {
                    $output .= $this->displayError($this->l('The fixed percentage should be a valid number'));
                }
            } elseif (!Validate::isEmail($order_email)) {
                $output .= $this->displayError($this->l('Order email is invalid'));
            } elseif (!empty($customer_id) && !Validate::isInt($customer_id)) {
                $output .= $this->displayError($this->l('Customer id is invalid'));
            } else {
                $ced_api_url = Configuration::get('CEDTRADERA_API_URL');
                $cedtradera_app_id = Configuration::get('CEDTRADERA_APP_ID');
                $cedtradera_app_key = Configuration::get('CEDTRADERA_APP_KEY');
                $cedtradera_secret_key = Configuration::get('CEDTRADERA_SECRET_KEY');
                $cedtradera_accept_url = Configuration::get('CEDTRADERA_ACCEPT_URL');
                $cedtradera_reject_url = Configuration::get('CEDTRADERA_REJECT_URL');
                // $cedtradera_code = Configuration::get('CEDTRADERA_CODE');
                $cedtradera_token = Configuration::get('CEDTRADERA_API_ACCESS_TOKEN');
                $cedtradera_access_expiry = Configuration::get('CEDTRADERA_ACCESS_EXPIRY');
                if (empty($ced_api_url)
                    || empty($cedtradera_app_id)
                    || empty($cedtradera_app_key)
                    || empty($cedtradera_secret_key)
                ) {
                    $output .= $this->displayError($this->l('Invalid Api credentials. '));
                } elseif (Tools::strlen($cedtradera_secret_key) < 32
                ) {
                    $output .= $this->displayError(
                       $this->l('The length of Secret Key must be between 32 and 255 characters')
                    );
                } elseif (!Validate::isAbsoluteUrl($cedtradera_accept_url)) {
                    $output .= $this->displayError($this->l('Accept Url is not valid'));
                } elseif (!Validate::isAbsoluteUrl($cedtradera_reject_url)) {
                    $output .= $this->displayError($this->l('Reject Url is not valid'));
                } else {
                    $output .= $this->displayConfirmation("Tradera configuration saved successfully");
                }
            }
        }

        $output = $this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl');

        return $output.$this->getGeneralSettingForm().$this->displaySettingForm();
    }
    // create settings form for basic credentials

    public function displaySettingForm()
    {
        $fields_form = array();
        $fields_form[0]['form'] = $this->getProductSettingForm();
        $fields_form[1]['form'] = $this->getOrderSettingForm();
        $fields_form[2]['form'] = $this->getCronInfoForm();
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get(
            'PS_BO_ALLOW_EMPLOYEE_FORM_LANG'
        ) ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'traderasettings';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).
            '&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );
        return $helper->generateForm($fields_form);
    }

    public function getGeneralSettingForm()
    {   
        $config_values = $this->getConfigFormValues();
        $this->context->smarty->assign($config_values);
        $this->context->smarty->assign(array(
            'accept_url' => Configuration::get('CEDTRADERA_ACCEPT_URL')
        ));
        $this->context->smarty->assign(array(
            'reject_url' => Configuration::get('CEDTRADERA_REJECT_URL')
        ));
        $general_setting_form = $this->context->smarty
            ->fetch(_PS_MODULE_DIR_.'cedtradera/views/templates/admin/configuration/general_settings.tpl');
        return $general_setting_form;
    }

    public function getProductSettingForm()
    {
        $this->context->smarty->assign(array(
            'CEDTRADERA_PRICE_VARIATION_TYPE' => Configuration::get('CEDTRADERA_PRICE_VARIATION_TYPE')
        ));
        $price_variation_html =  $this->context->smarty
            ->fetch(_PS_MODULE_DIR_.'cedtradera/views/templates/admin/configuration/price_variation.tpl');
        $store_languages = array();

        $store_languages_list = Language::getLanguages(true);

        foreach ($store_languages_list as $languages) {
            if (isset($languages['id_lang']) && $languages['id_lang']
                && isset($languages['name']) && $languages['name']
                && isset($languages['active']) && $languages['active']) {
                array_push($store_languages, array(
                    'id'=>$languages['id_lang'],
                    'name'=>$languages['name']));
            }
        }
        return array(
            'legend'  => array(
                'title'  => $this->l('Product Settings'),
                'icon'  => 'icon-cogs'
            ),
            'input'  => array(
                array(
                    'type' => 'select',
                    'label' => $this->l('Price Type'),
                    'name' => 'CEDTRADERA_PRICE_TYPE',
                    'required' => false,
                    'desc' => $this->l('The type of product price send to Tradera.com.'),
                    'default_value' => '',
                    'options' => array(
                        'query' => array(
                            array('value' => 'priceWithoutTax', 'label' => 'Normal Price Without Tax'),
                            array('value' => 'priceWithTax', 'label' => 'Normal Price With tax'),
                        ),
                        'id' => 'value',
                        'name' => 'label',
                    )
                ),
                array(
                    'type'  => 'html',
                    'label'  => $this->l('Advance Pricing'),
                    'name' => $price_variation_html,
                    'col' => 6,
                ),
                array(
                    'col' => 6,
                    'type' => 'text',
                    'id' => 'fixed_price',
                    'prefix' => '<i class="icon icon-money"></i>',
                    'desc' => $this->l('Enter the Fixed amount which is to be added 
                    in product default price while uploading or updating at Tradera.'),
                    'name' => 'CEDTRADERA_PRICE_VARIATION_FIXED',
                    'label' => $this->l(' Fixed Amount'),
                ),
                array(
                    'col' => 6,
                    'type' => 'text',
                    'id' => 'fixed_per',
                    'prefix' => '<i class="icon icon-money"></i>',
                    'desc' => $this->l('Enter the Fixed percent which is to be added 
                    in product default price while uploading or updating at Tradera. 
                    Do not include any symbol like "%" etc.'),
                    'name' => 'CEDTRADERA_PRICE_VARIATION_PER',
                    'label' => $this->l(' Fixed Percentage'),
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Store Language'),
                    'desc' => $this->l('Store Language In Which Data Process.'),
                    'name' => 'CEDTRADERA_LANGUAGE_STORE',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $store_languages,
                        'id' => 'id',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Auto Sync Inventory and Price By Cron'),
                    'name' => 'CEDTRADERA_AUTO_SYNC',
                    'is_bool' => true,
                    'desc' => $this->l('If enable then QUANTITY and PRICE will be automatically SYNCHRONIZED By Cron.'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('No')
                        )
                    ),
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Update Inventory/Price on Product Edit.'),
                    'name' => 'CEDTRADERA_UPDATE_INV_PRICE',
                    'is_bool' => true,
                    'desc' => $this->l('Update inventory and price on tradera when you edit product on store .'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('No')
                        )
                    ),
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Delete Product Data on Product Delete.'),
                    'name' => 'CEDTRADERA_AUTO_DELETE_PRODUCT',
                    'is_bool' => true,
                    'desc' => $this->l('Disable product on tradera when you delete product on store .'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('No')
                        )
                    ),
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Debug Mode'),
                    'name' => 'CEDTRADERA_DEBUG_MODE',
                    'is_bool' => true,
                    'desc' => $this->l('If enable Error and info will be logged in db.'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('No')
                        )
                    ),
                ),
            )
        );
    }

    public function getOrderSettingForm()
    {
        $db = Db::getInstance();
        $id_lang = ((int) Configuration::get('CEDTRADERA_LANGUAGE_STORE'))?
            (int) Configuration::get('CEDTRADERA_LANGUAGE_STORE')
            :(int) Configuration::get('PS_LANG_DEFAULT');

        $order_states = $db->ExecuteS("SELECT `id_order_state`,`name` 
       FROM `"._DB_PREFIX_."order_state_lang` WHERE `id_lang` = '".(int)$id_lang."'");

        $order_carriers = $db->ExecuteS("SELECT `id_carrier`,`name` 
        FROM `"._DB_PREFIX_."carrier` WHERE `active` = '1'");

        $payment_methods = array();

        $modules_list = Module::getPaymentModules();

        foreach ($modules_list as $module) {
            $module_obj = Module::getInstanceById($module['id_module']);
            if ($module_obj) {
                array_push($payment_methods, array('id'=>$module_obj->name,'name'=>$module_obj->displayName));
            }
        }

        return array(
            'legend'  => array(
                'title'  => $this->l('Order Settings'),
                'icon'  => 'icon-cogs'
            ),
            'input'  => array(
                array(
                    'type' => 'switch',
                    'label' => $this->l('Auto Reject failed Orders'),
                    'name' => 'CEDTRADERA_AUTO_REJECT',
                    'is_bool' => true,
                    'desc' => $this->l('If enable the imported order will be 
                               cancelled automatically at tradera in case of any order error.'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('No')
                        )
                    ),
                ),
                array(
                    'col' => 6,
                    'type' => 'text',
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('Email to create order on store which are imported from tradera.'),
                    'name' => 'CEDTRADERA_ORDER_EMAIL',
                    'label' => $this->l(' ORDER EMAIL'),
                ),
                array(
                    'col' => 6,
                    'type' => 'text',
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('Customer Id to create order on store which are imported from tradera.'),
                    'name' => 'CEDTRADERA_CUSTOMER_ID',
                    'label' => $this->l('CUSTOMER ID'),
                ),
                array(
                    'col' => 6,
                    'type' => 'select',
                    'label' => $this->l('Order status when Import'),
                    'desc' => $this->l('Order Status While importing order.'),
                    'name' => 'CEDTRADERA_ORDER_STATE_IMPORT',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
                array(
                    'col' => 6,
                    'type' => 'select',
                    'label' => $this->l('Order status when cancelled at Tradera'),
                    'desc' => $this->l('Order Status after cancel order.'),
                    'name' => 'CEDTRADERA_ORDER_STATE_CANCEL',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
                array(
                    'col' => 6,
                    'type' => 'select',
                    'label' => $this->l('Order status when Shipped'),
                    'desc' => $this->l('Order Status after order Shipped.'),
                    'name' => 'CEDTRADERA_ORDER_STATE_SHIPPED',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
                array(
                    'col' => 6,
                    'type' => 'select',
                    'label' => $this->l('Order status when Refunded'),
                    'desc' => $this->l('Order Status after order Refunded from store.'),
                    'name' => 'CEDTRADERA_ORDER_STATE_REFUNDED',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
                array(
                    'col' => 6,
                    'type' => 'select',
                    'label' => $this->l('Order Carrier'),
                    'desc' => $this->l('Order Carrier While importing order.'),
                    'name' => 'CEDTRADERA_ORDER_CARRIER',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_carriers,
                        'id' => 'id_carrier',
                        'name' => 'name',
                    )
                ),
                array(
                    'col' => 6,
                    'type' => 'select',
                    'label' => $this->l('Order Payment'),
                    'desc' => $this->l('Order Payment While importing order.'),
                    'name' => 'CEDTRADERA_ORDER_PAYMENT',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $payment_methods,
                        'id' => 'id',
                        'name' => 'name',
                    )
                ),
                array(
                    'col' => 6,
                    'type' => 'select',
                    'label' => $this->l('Order From Date'),
                    'desc' => $this->l('Order to get from that date'),
                    'name' => 'CEDTRADERA_ORDER_FROM_DATE',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => array(
                            array('value' => '', 'label' => 'Select From Date'),
                            array('value' => 1, 'label' => '1'),
                            array('value' => 2, 'label' => '2'),
                            array('value' => 3, 'label' => '3'),
                            array('value' => 4, 'label' => '4'),
                            array('value' => 5, 'label' => '5'),
                            array('value' => 6, 'label' => '6'),
                            array('value' => 7, 'label' => '7'),
                        ),
                        'id' => 'value',
                        'name' => 'label',
                    ),
                ),
            ),
        );
    }

    public function getCronInfoForm()
    {
        $this->context->smarty->assign(array(
            'base_url' => Context::getContext()->shop->getBaseURL(true),
            'cron_secure_key' => Configuration::get('CEDTRADERA_CRON_SECURE_KEY')
        ));
        $cron_html = $this->display(
            __FILE__,
            'views/templates/admin/configuration/cron_table.tpl'
        );
        return array(
            'legend' => array(
                'title' => $this->l('Cron Info'),
                'icon' => 'icon-info',
            ),
            'input' => array(
                array(
                    'col' => 6,
                    'type' => 'text',
                    'id' => 'CEDTRADERA_CRON_SECURE_KEY',
                    'required' => true,
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'name' => 'CEDTRADERA_CRON_SECURE_KEY',
                    'label' => $this->l(' Cron Secure Key'),
                    'desc' => $this->l('This cron secure key need to set in 
                    the parameters of following cron urls'),
                ),

                array(
                    'col' => 6,
                    'type'  => 'html',
                    'label'  => $this->l(''),
                    'name' => $cron_html,
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
            ),
        );
    }

    public function hookActionProductUpdate($params)
    {
        $cedTraderaProduct = new CedTraderaProduct();
        $cedTraderaHelper = new CedTraderaHelper();
        try {
            $idProduct = isset($params['id_product']) ? $params['id_product']: null;
            if (!empty($idProduct)) {
                if (Configuration::get('CEDTRADERA_UPDATE_INV_PRICE')) {
                    $result = $cedTraderaProduct->updateInventoryPrice($idProduct);
                    $cedTraderaHelper->log(
                        __METHOD__,
                        'Info',
                        'Hook Product Update '.$idProduct,
                        Tools::jsonEncode(
                            array(
                                'response' => $result
                            )
                        )
                    );
                }
            }
        } catch (\Exception $e) {
            $cedTraderaHelper->log(
                __METHOD__,
                'Exception',
                $e->getMessage(),
                Tools::jsonEncode(
                    array(
                        'Trace' => $e->getTraceAsString()
                    )
                ),
                true
            );
        }
    }
    public function hookActionUpdateQuantity($params)
    {
        $cedTraderaProduct = new CedTraderaProduct();
        $cedTraderaHelper = new CedTraderaHelper();
        try {
            $idProduct = isset($params['id_product']) ? $params['id_product']: null;
            if (!empty($idProduct)) {
                if (Configuration::get('CEDTRADERA_UPDATE_INV_PRICE')) {
                    $result = $cedTraderaProduct->updateInventoryPrice($idProduct);
                    $cedTraderaHelper->log(
                        __METHOD__,
                        'Info',
                        'Hook Update Quantity '.$idProduct,
                        Tools::jsonEncode(
                            array(
                                'response' => $result
                            )
                        )
                    );
                }
            }
        } catch (\Exception $e) {
            $cedTraderaHelper->log(
                __METHOD__,
                'Exception',
                $e->getMessage(),
                Tools::jsonEncode(
                    array(
                        'Trace' => $e->getTraceAsString()
                    )
                ),
                true
            );
        }
    }

    //hook to disable product at Tradera after product is deleted from shop
    public function hookActionProductDelete($params)
    {
        $cedTraderaProduct = new CedTraderaProduct();
        $cedTraderaHelper = new CedTraderaHelper();
        try {
            $idProduct = isset($params['id_product']) ? $params['id_product']: null;
            if (!empty($idProduct)) {
                if (Configuration::get('CEDTRADERA_AUTO_DELETE_PRODUCT')) {
                    $result = $cedTraderaProduct->enableDisableTraderaProduct($idProduct, 'disable');
                    $cedTraderaHelper->log(
                        __METHOD__,
                        'Info',
                        'Hook Product Delete '.$idProduct,
                        Tools::jsonEncode(
                            array(
                                'response' => $result
                            )
                        )
                    );
                }
            }
        } catch (\Exception $e) {
            $cedTraderaHelper->log(
                __METHOD__,
                'Exception',
                $e->getMessage(),
                Tools::jsonEncode(
                    array(
                        'Trace' => $e->getTraceAsString()
                    )
                ),
                true
            );
        }
    }

    public function hookDisplayBackOfficeHeader($params)
    {
        if (!Module::isEnabled($this->name)) {
            return false;
        }
        if (method_exists($this->context->controller, 'addCSS')) {
            $this->context->controller->addCSS($this->_path.'views/css/tab.css');
        }
        if (method_exists($this->context->controller, 'addJquery')) {
            $this->context->controller->addJquery();
        }
    }

    public function getConfigFormValues()
    {
        return array(
            'CEDTRADERA_MODE' => Configuration::get('CEDTRADERA_MODE') ?
                Configuration::get('CEDTRADERA_MODE'): 'sandbox',
            'CEDTRADERA_LIVE_MODE' => Configuration::get('CEDTRADERA_LIVE_MODE') ?
                Configuration::get('CEDTRADERA_LIVE_MODE'): 1,
            'CEDTRADERA_API_URL' => Configuration::get('CEDTRADERA_API_URL') ?
                Configuration::get('CEDTRADERA_API_URL'): '',
            'CEDTRADERA_APP_ID' => Configuration::get('CEDTRADERA_APP_ID') ?
                Configuration::get('CEDTRADERA_APP_ID'): '',
            'CEDTRADERA_APP_KEY' => Configuration::get('CEDTRADERA_APP_KEY') ?
                Configuration::get('CEDTRADERA_APP_KEY'): '',
            'CEDTRADERA_SECRET_KEY' => Configuration::get('CEDTRADERA_SECRET_KEY') ?
                Configuration::get('CEDTRADERA_SECRET_KEY'): '',
            'CEDTRADERA_USER_ID' => Configuration::get('CEDTRADERA_USER_ID') ?
                Configuration::get('CEDTRADERA_USER_ID'): '',
            'CEDTRADERA_ACCEPT_URL' => Configuration::get('CEDTRADERA_ACCEPT_URL') ?
                Configuration::get('CEDTRADERA_ACCEPT_URL'):
                Context::getContext()->shop->getBaseURL(true).
                'index.php?module=cedtradera&controller=authorization',
            'CEDTRADERA_REJECT_URL' => Configuration::get('CEDTRADERA_REJECT_URL') ?
                Configuration::get('CEDTRADERA_REJECT_URL'):
                Context::getContext()->shop->getBaseURL(true).
                'index.php?module=cedtradera&controller=authorization',
            'CEDTRADERA_DEBUG_MODE' => Configuration::get('CEDTRADERA_DEBUG_MODE') ?
                Configuration::get('CEDTRADERA_DEBUG_MODE'): 0,
            'CEDTRADERA_API_ACCESS_TOKEN' => Configuration::get('CEDTRADERA_API_ACCESS_TOKEN') ?
                Configuration::get('CEDTRADERA_API_ACCESS_TOKEN'): '',
            //'CEDTRADERA_CODE' => Configuration::get('CEDTRADERA_CODE') ?
               // Configuration::get('CEDTRADERA_CODE'): '',
            'CEDTRADERA_ACCESS_EXPIRY' => Configuration::get('CEDTRADERA_ACCESS_EXPIRY') ?
                Configuration::get('CEDTRADERA_ACCESS_EXPIRY'): '',
            'CEDTRADERA_PRICE_TYPE' => Configuration::get('CEDTRADERA_PRICE_TYPE') ?
                Configuration::get('CEDTRADERA_PRICE_TYPE'): '',
            'CEDTRADERA_PRICE_VARIATION_TYPE' => Configuration::get('CEDTRADERA_PRICE_VARIATION_TYPE') ?
                Configuration::get('CEDTRADERA_PRICE_VARIATION_TYPE'): '',
            'CEDTRADERA_PRICE_VARIATION_FIXED' => Configuration::get('CEDTRADERA_PRICE_VARIATION_FIXED') ?
                Configuration::get('CEDTRADERA_PRICE_VARIATION_FIXED'): '',
            'CEDTRADERA_PRICE_VARIATION_PER' => Configuration::get('CEDTRADERA_PRICE_VARIATION_PER') ?
                Configuration::get('CEDTRADERA_PRICE_VARIATION_PER'): '',
            'CEDTRADERA_LANGUAGE_STORE' => Configuration::get('CEDTRADERA_LANGUAGE_STORE') ?
                Configuration::get('CEDTRADERA_LANGUAGE_STORE'): '',
            'CEDTRADERA_AUTO_SYNC' => Configuration::get('CEDTRADERA_AUTO_SYNC') ?
                Configuration::get('CEDTRADERA_AUTO_SYNC'): 0,
            'CEDTRADERA_UPDATE_INV_PRICE' => Configuration::get('CEDTRADERA_UPDATE_INV_PRICE') ?
                Configuration::get('CEDTRADERA_UPDATE_INV_PRICE'): 0,
            'CEDTRADERA_AUTO_DELETE_PRODUCT' => Configuration::get('CEDTRADERA_AUTO_DELETE_PRODUCT') ?
                Configuration::get('CEDTRADERA_AUTO_DELETE_PRODUCT'): 0,
            'CEDTRADERA_ORDER_EMAIL' => Configuration::get('CEDTRADERA_ORDER_EMAIL') ?
                Configuration::get('CEDTRADERA_ORDER_EMAIL'): '',
            'CEDTRADERA_CUSTOMER_ID' => Configuration::get('CEDTRADERA_CUSTOMER_ID') ?
                Configuration::get('CEDTRADERA_CUSTOMER_ID'): '',
            'CEDTRADERA_AUTO_REJECT' => Configuration::get('CEDTRADERA_AUTO_REJECT') ?
                Configuration::get('CEDTRADERA_AUTO_REJECT'): 0,
            'CEDTRADERA_ORDER_STATE_IMPORT' => Configuration::get('CEDTRADERA_ORDER_STATE_IMPORT') ?
                Configuration::get('CEDTRADERA_ORDER_STATE_IMPORT'): '',
            'CEDTRADERA_ORDER_STATE_CANCEL' => Configuration::get('CEDTRADERA_ORDER_STATE_CANCEL') ?
                Configuration::get('CEDTRADERA_ORDER_STATE_CANCEL'): '',
            'CEDTRADERA_ORDER_STATE_SHIPPED' => Configuration::get('CEDTRADERA_ORDER_STATE_SHIPPED') ?
                Configuration::get('CEDTRADERA_ORDER_STATE_SHIPPED'): '',
            'CEDTRADERA_ORDER_STATE_REFUNDED' => Configuration::get('CEDTRADERA_ORDER_STATE_REFUNDED') ?
                Configuration::get('CEDTRADERA_ORDER_STATE_REFUNDED'): '',
            'CEDTRADERA_ORDER_CARRIER' => Configuration::get('CEDTRADERA_ORDER_CARRIER') ?
                Configuration::get('CEDTRADERA_ORDER_CARRIER'): '',
            'CEDTRADERA_ORDER_PAYMENT' => Configuration::get('CEDTRADERA_ORDER_PAYMENT') ?
                Configuration::get('CEDTRADERA_ORDER_PAYMENT'): '',
            'CEDTRADERA_CRON_SECURE_KEY' => Configuration::get('CEDTRADERA_CRON_SECURE_KEY') ?
                Configuration::get('CEDTRADERA_CRON_SECURE_KEY'): '',
                'CEDTRADERA_ORDER_FROM_DATE' => Configuration::get('CEDTRADERA_ORDER_FROM_DATE') ? Configuration::get('CEDTRADERA_ORDER_FROM_DATE') : '',
        );
    }
}
