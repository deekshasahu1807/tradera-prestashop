<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedTradera
 */

include_once _PS_MODULE_DIR_ . 'cedtradera/classes/CedTraderaHelper.php';

class CedTraderaProduct
{
    public function __construct() 
    {
        $this->api_url = Configuration::get('CEDTRADERA_API_URL');
        $this->userId = Configuration::get('CEDTRADERA_USER_ID');
        $this->secretKey = Configuration::get('CEDTRADERA_SECRET_KEY');
        $this->appId = Configuration::get('CEDTRADERA_APP_ID');
        $this->appKey = Configuration::get('CEDTRADERA_APP_KEY');
        $this->token = Configuration::get('CEDTRADERA_API_ACCESS_TOKEN');    
    }

	public function getAllMappedCategories()
    {
        $db = Db::getInstance();
        $row = $db->ExecuteS("SELECT `store_category` 
        FROM `" . _DB_PREFIX_ . "cedtradera_profile` 
        WHERE `store_category` != ''");

        if (isset($row['0']) && $row['0']) {
            $mapped_categories = array();
            foreach ($row as $value) {
                $mapped_categories = array_merge($mapped_categories, json_decode($value['store_category'], true));
            }
            return $mapped_categories;
        } else {
            return array();
        }
    }

    public function uploadProducts($product_ids)
    {
        $CedTraderaHelper = new CedTraderaHelper;
        $db = Db::getInstance();
        $product_ids = array_filter($product_ids);
        $product_ids = array_unique($product_ids);
        $validation_error = array();

        if (!empty($product_ids)) {
            $productToUpload  = array();
            $itemCount = 0;
            foreach ($product_ids as $product_id) {
                if (is_numeric($product_id)) 
                {
                    $profile_info = $this->getProfileByProductId($product_id);

                    if(isset($profile_info['tradera_item_id']) && !empty($profile_info['tradera_item_id']) && $profile_info['tradera_item_id'] != '0') 
                    {
                        // $productToUpload .= " <soap:Body>";
                        // $productToUpload .= "<UpdateShopItem xmlns='http://api.tradera.com'>";
                        // $productToUpload .= "<updateData>";
                        // $productToUpload .= "<ItemId>";
                        $productToUpload['item_id'] = $profile_info['tradera_item_id'];
                        // $productToUpload .= "</ItemId>";
                        // $productToUpload .= "<ItemData>";
                    } else {
                        $productToUpload['item_id'] = (int)'0';
                        // $productToUpload .= " <soap:Body>";
                        // $productToUpload .= "<AddShopItem xmlns='http://api.tradera.com'>";
                        // $productToUpload .= "<shopItemData>";
                    }
                    $default_lang = isset($profile_info['0']['profile_language']) ? $profile_info['0']['profile_language'] : Configuration::get('PS_LANG_DEFAULT');

                    // $product = $this->getProduct($product_id);
                    $product = (array)new Product($product_id, true, $default_lang);

                    // echo '<pre>'; print_r($product); die;
                    if ($profile_info && !empty($product)) {

                        $product_info = $this->getCedTraderaMappedProductData($product_id, $profile_info, $product);

                        // echo "<pre>";print_r($profile_info);die;

                        $category = $this->getCedTraderaCategory($product_id, $profile_info);

                        $price = $this->getCedTraderaPrice($product_id, $product);
                        
                        $stock = $this->getCedTraderaQuantity($product_id, $product);

                        $attributes = $this->getCedTraderaAttribute($product_id, $profile_info, $product);

                        $attribute_type = $this->getCedTraderaAttributeType($product_id, $profile_info['0']['id']);

                        if(isset($product_info['ActivateDate']) && $product_info['ActivateDate']) 
                        {
                            $time=strtotime($product_info['ActivateDate']);
                            $hour=date("H",$time);
                            $min=date("i",$time);
                            $sec=date("s",$time);
                            $month=date("m",$time);
                            $day=date("d",$time);
                            $year=date("Y",$time);

                            $activate_date = date('Y-m-d H:i:s', mktime($hour, $min, $sec, $month, $day, $year));
                            $activate_date = str_ireplace(' ', 'T', $activate_date);
                            
                           // $productToUpload .= "<ActivateDate>";
                           $productToUpload['activate_date'] =  $activate_date;
                           // $productToUpload .= "</ActivateDate>";
                        }

                        // $productToUpload .= "<AcceptedBuyerId>";
                        // $productToUpload .= '';
                        // $productToUpload .= "</AcceptedBuyerId>";

                        if(!empty($category)){
                            // $productToUpload .= "<CategoryId>";
                            $productToUpload['category_id'] = (int)$category;
                            // $productToUpload .= "</CategoryId>";
                        }

                        if(isset($product_info['DeactivateDate']) && $product_info['DeactivateDate']) {
                                $time=strtotime($product_info['DeactivateDate']);
                                $hour=date("H",$time);
                                $min=date("i",$time);
                                $sec=date("s",$time);
                                $month=date("m",$time);
                                $day=date("d",$time);
                                $year=date("Y",$time);

                                 $deactivate_date = date('Y-m-d H:i:s', mktime($hour, $min, $sec, $month, $day, $year));
                                 $deactivate_date = str_ireplace(' ', 'T', $deactivate_date);

                              // $productToUpload .= "<DeactivateDate>";
                              $productToUpload['deactivate_date'] = $deactivate_date;
                              // $productToUpload .= "</DeactivateDate>";
                        }

                        if(!empty($attribute_type))
                        {
                            // $productToUpload .= "<ItemAttributes>";
                            // $productToUpload .= "<int>";
                            $productToUpload['attribute_type'] = (int)$attribute_type;
                            // $productToUpload .= "<int>";
                            // $productToUpload .= "</ItemAttributes>";
                        }

                        if(isset( $product_info['Description']) &&  $product_info['Description']) {
                            $description = (string) (strip_tags(substr(html_entity_decode($product_info['Description']),0,2994).'...'));
                            $description  = htmlspecialchars_decode(str_replace('&nbsp;', '', $description));
                            // $productToUpload .= "<Description>";
                            $productToUpload['description'] = $description;
                            // $productToUpload .= "</Description>";
                            } else {
                            $validation_error[$itemCount] = 'Product ID '.$product_id.'Description is required Field';
                        }

                        // $productToUpload .= "<PaymentCondition>";
                        // $productToUpload .= '';
                        // $productToUpload .= "</PaymentCondition>";

                        if(!empty($price))
                        {
                            // $productToUpload .= "<Price>";
                            $productToUpload['price'] = (float)$price;
                            // $productToUpload .= "</Price>";
                        }

                        if(!empty($stock))
                        {
                            // $productToUpload .= "<Quantity>";
                            $productToUpload['quantity'] = (int)$stock;
                            // $productToUpload .= "</Quantity>";
                        }

                        // $productToUpload .= "<ShippingCondition>";
                        // $productToUpload .= '';
                        // $productToUpload .= "</ShippingCondition>";

                        if (isset($product_info['Title']) &&  $product_info['Title']) 
                        {
                            // $productToUpload .= "<Title>";
                            $productToUpload['title'] = (string)$product_info['Title'];
                            // $productToUpload .= "</Title>";
                        } else {
                            $validation_error[$itemCount] = 'Product ID ' . $product_id . 'Title is required Field';
                        }

                        if(isset( $product_info['VAT']) && $product_info['VAT']) 
                        {
                            // $productToUpload .= "<VAT>";
                            $productToUpload['vat'] = (int)$product_info['VAT'];
                            // $productToUpload .= "</VAT>";
                        }

                        // $productToUpload .= "<ShippingOptions>";
                        // $productToUpload .= "<ItemShipping>";
                        // $productToUpload .= "<ShippingOptionId>";
                        $productToUpload['shipping_id'] = (int)'';
                        // $productToUpload .= "</ShippingOptionId>";
                        // $productToUpload .= "<Cost>";
                        $productToUpload['shipping_cost'] = (int)'';
                        // $productToUpload .= "</Cost>";
                        // $productToUpload .= "</ItemShipping>";
                        // $productToUpload .= "</ShippingOptions>";
                        // $productToUpload .= "<PaymentOptionIds>";
                        // $productToUpload .= "<int>";
                        $productToUpload['payment_id'] = (int)'';
                        // $productToUpload .= "</int>";
                        // $productToUpload .= "</PaymentOptionIds>";

                        if(isset($product['reference']) &&  $product['reference']) {
                            // $productToUpload .= "<OwnReferences>";
                            // $productToUpload .= "<string>";
                            $productToUpload['reference'] = (string)$product['reference'];
                            // $productToUpload .= "<string>";
                            // $productToUpload .= "</OwnReferences>";
                        }

                        // if(!empty($attributes)){
                        //     $productToUpload['attributes'] =  $attributes;
                        // } else {
                        //     $productToUpload['attributes'] =  array(array('attributes_id' => 19428, 'value' => (string)'No Brand'));
                        // }

                        $images = $CedTraderaHelper->productSecondaryImageURL($product_id);

                        if (!empty($images)) {
                            if(isset($images['mainImageUrl']) && !empty($images['mainImageUrl'])) {
                                $itemImageNames = array($images['mainImageUrl']);
                            } else if(isset($images['productSecondaryImageURL']) && !empty($images['productSecondaryImageURL'])) {
                                $secondary_image = array($images['productSecondaryImageURL']);
                                $itemImageNames = array_merge($main_image, $secondary_image);
                            }
                           
                            $itemImages = array();
                            $productToUpload['images'] = array();
                            foreach ($itemImageNames as $key => $itemImageName) 
                            {
                                $filename = basename($itemImageName);
                                // $itemImageData = new StdClass();
                                // $itemImageData->Format = explode('.', $filename)[1];
                                // $itemImageData->Data = file_get_contents($itemImageName);
                                // $itemImageData->Name = explode('.', $filename)[0];
                                // $itemImageData->HasMega = true;
                                // array_push($itemImages, $itemImageData);
                                // $productToUpload .= "<ItemImageData>";
                                // $productToUpload .= "<HasMega>";
                                $image['has_mega'] = (boolean)true;
                                // $productToUpload .= "</HasMega>";
                                // $productToUpload .= "<Format>";
                                $format = explode('.', $filename)[1];
                                if($format == 'jpg')
                                    $format = 'jpeg';
                                $image['format'] = ucwords($format);
                                // $productToUpload .= "</Format>";
                                // $productToUpload .= "<Data>";
                                $image['data'] = $itemImageName;
                                // $productToUpload .= "</Data>";
                                // $productToUpload .= "<Name>";
                                $image['name'] = explode('.', $filename)[0];
                                // $productToUpload .= "</Name>";
                                // $productToUpload .= "</ItemImageData>";
                                $productToUpload['images'][] = $image;
                            }
                            // $productToUpload .= "</ItemImages>";
                        } else {
                            $validation_error[$itemCount] = 'Product ID '.$product_id.'Image is required Field';
                        }

                        // $productToUpload .= "<ExternalId>";
                        // $productToUpload .= (int)'';
                        // $productToUpload .= "</ExternalId>";

                        // $result = $db->executeS("SELECT tradera_item_id FROM `"._DB_PREFIX_."cedtradera_uploaded_products` WHERE product_id='".$product_id."'");

                        // $productToUpload['item_id'] = isset($result['tradera_item_id']) ? (int)$result['tradera_item_id'] : '0';

                        // if ($variants = $this->isVariantProduct($product_id, $profile_info['0']['profile_language'])) {
                        //     $productToUpload['variations'] = (array) $variants;
                        // }

                        if(isset($profile_info['tradera_item_id']) && !empty($profile_info['tradera_item_id']) && $profile_info['tradera_item_id'] != '0') 
                    {
                        // $productToUpload .= "</ItemData>";
                        // $productToUpload .= "</updateData>";
                        // $productToUpload .= "</UpdateShopItem>";
                        // $productToUpload .= "</soap:Body>";
                    } else {
                        // $productToUpload .= "</shopItemData>";
                        // $productToUpload .= "</AddShopItem>";
                        // $productToUpload .= "</soap:Body>";
                    }

                        //$valid = $this->validateProduct($productToUpload, $category);
                    // echo "<pre>";print_r($productToUpload);die;

                    $CedTraderaHelper->addShopItem($productToUpload);
                        // if (isset($valid['success']) && $valid['success']) 
                        // {
                             //  $itemCount++;
                             // if (count($productToUpload) && (count($validation_error) == 0)) {
                             //     if(isset($productToUpload['item_id']) && $productToUpload['item_id']) {
                             //             // unset($productToUpload['images']);
                             //            $response = $CedTraderaHelper->traderaPostRequest('/v3/RestrictedService.asmx', 'UpdateShopItem', $productToUpload);
                             //            $response = $response['message'];
                             //            $response = $response['soap:Envelope']['soap:Body']['UpdateShopItemResponse']['UpdateShopItemResult'];
                             //        } else {
                             //            $response = $CedTraderaHelper->traderaPostRequest('/v3/RestrictedService.asmx', 'AddShopItem', $productToUpload);

                             //            $response = $response['message'];
                                         
                             //            $response = $response['soap:Envelope']['soap:Body']['AddShopItemResponse']['AddShopItemResult'];
                             //            //echo '<pre>'; print_r($response); die;
                             //        }
                             //        if (isset($response['ItemId']) && $response['ItemId']) 
                             //        {
                             //            $db->insert(
                             //                'cedtradera_uploaded_products',
                             //                array(
                             //                    'product_id' => (int)$product_id,
                             //                    'tradera_item_id' => (int)$response['ItemId'],
                             //                    'tradera_status' => pSQL('Uploaded')
                             //                    )
                             //                );

                             //            return array('success' => true, 'message' => 'Product ' . $product_id . ' uploaded successfully');
                             //            $alreadyExist = $db->executeS("SELECT * FROM `".DB_PREFIX."cedtradera_uploaded_products` WHERE product_id = '".(int)$product_id."'");
                             //                if (isset($alreadyExist) && count($alreadyExist)) {
                             //                $db->update(
                             //                    'cedtradera_uploaded_products',
                             //                    array(
                             //                    'tradera_item_id' => (int)$response['ItemId'],
                             //                    'tradera_status' => pSQL('Uploaded')
                             //                        ),
                             //                    'product_id="'.(int)$product_id.'" '
                             //                    );
                             //                } else {
                             //                    $db->insert(
                             //                    'cedtradera_uploaded_products',
                             //                    array(
                             //                        'product_id' => (int)$product_id,
                             //                        'tradera_item_id' => (int)$response['ItemId'],
                             //                        'tradera_status' => pSQL('Uploaded')
                             //                        ),
                             //                    'product_id="'.(int)$product_id.'" '
                             //                    );
                             //                }
                                        
                             //        } else if (isset($response['error']) && isset($response['message']) && $response['message']) {
                             //            $msg = isset($response['message']) ? $response['message'] : $response['error'];
                             //            return array('success' => false, 'message' => 'Product Id:' . $product_id . ':' . $msg);
                             //        } else if(isset($response['error']) && $response['error']) {
                             //                return array('success' => false, 'message' => 'Product Id:' . $product_id . ':' . $response['error']);
                             //            }
                             //    } else {
                             //        return array('success' => false, 'message' => $validation_error);
                             //    }
                        // } else {
                        //     return array('success' => false, 'message' => 'Required Attribute are Missing : -'.$valid['message']);
                        // }
                    } else {
                        continue;
                    }
                }
            }
            
            
        }
    }


    public function getProfileByProductId($product_id)
    {
        if ($product_id) {
            $result = Db::getInstance()->executeS("SELECT * FROM `" . _DB_PREFIX_ . "cedtradera_profile` cp LEFT JOIN `" . _DB_PREFIX_ . "cedtradera_profile_products` cpp on (cp.id = cpp.tradera_profile_id) WHERE cpp.product_id='" . $product_id . "'");
            if (isset($result) && count($result)) {
                return $result;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function getCedTraderaMappedProductData($product_id, $profile_info, $product)
    {
        $response = array();
        $profile_info = $profile_info['0'];
        $response['tradera_category'] = $profile_info['tradera_category'];
        if ($product_id && isset($profile_info['default_mapping']) && $profile_info['default_mapping'])
        {
            $default_mapping = Tools::jsonDecode($profile_info['default_mapping'], true);
            if (!empty($default_mapping)) {
                $mapped_data = array();

                foreach ($default_mapping as $key => $value)
                {
                    if(($key == 'OwnReferences') || ($key == 'Title') || ($key == 'Description')  || ($key == 'Price') || ($key == 'Quantity'))
                    {
                        if(!empty($product[$value]))
                        {
                            $response[$key] = $product[$value];
                        } else {
                            $response[$key] = '';
                        }
                    } else {
                        $response[$key] = $value;
                    }
                }
            }

            $product_result = Db::getInstance()->executeS("SELECT * FROM `". _DB_PREFIX_ ."cedtradera_products` WHERE `product_id` = '". $product_id ."' ");

            if(isset($product_result['0']['default_product_values']) && $product_result['0']['default_product_values'])
            {
                $product_default_mapping = Tools::jsonDecode($product_result['0']['default_product_values'], true);

                if(isset($product_default_mapping) && is_array($product_default_mapping) && $product_default_mapping)
                {
                    $response = array_merge($response, $product_default_mapping);
                }
            }
        }

        return $response;
    }

    public function getCedTraderaCategory($product_id, $profile_info)
    {
        $profile_info = $profile_info['0'];
        if ($product_id) {
            $tradera_category = false;
            if (isset($profile_info['tradera_category']) && $profile_info['tradera_category']) {
                $tradera_category = $profile_info['tradera_category'];
            }
            return Tools::jsonDecode($tradera_category, true);
        } else {
            return false;
        }
    }

    public function getCedTraderaPrice($product_id, $product = array())
    {
        $product_price = 0;
        if (isset($product['price']) && $product['price']) {
            $product_price = $product['price'];
        } else {
            $query_price = Db::getInstance()->executeS("SELECT `price` FROM `" . _DB_PREFIX_ . "product` WHERE `id_product` = '" . (int)$product_id . "'");

            if (isset($query_price) && count($query_price)) {
                $product_price = $query_price['0']['price'];
            }
        }

        $price = (float)$product_price;
        // if (($specialPrice > 0) && ($specialPrice < $price)) {
        //     $price = $specialPrice;
        // }

        $cedtradera_price_choice = trim(Configuration::get(
            'CEDTRADERA_PRICE_VARIATION_TYPE'));

        switch ($cedtradera_price_choice) {
            case 'default':
               $price = $price;
               break;

            case 'increase_fixed':
                $fixedIncement = trim(Configuration::get('CEDTRADERA_PRICE_VARIATION_FIXED'));
                $price = $price + $fixedIncement;
                break;

            case 'decrease_fixed':
                $fixedIncement = trim(Configuration::get('CEDTRADERA_PRICE_VARIATION_FIXED'));
                $price = $price - $fixedIncement;
                break;


            case 'increase_per':
                $percentPrice = trim(Configuration::get('CEDTRADERA_PRICE_VARIATION_PER'));
                $price = (float)($price + (($price / 100) * $percentPrice));
                break;

            case 'decrease_per':
                $percentPrice = trim(Configuration::get('CEDTRADERA_PRICE_VARIATION_PER'));
                $price = (float)($price - (($price / 100) * $percentPrice));
                break;

            default:
                return (float)$price;
                break;
        }
        return (float)$price;
    }

    public function getCedTraderaQuantity($product_id, $product = array())
    {
        $quantity = 0;
        if(isset($product['quantity']) && $product['quantity']){
            $quantity = $product['quantity'];
        } else if($product_id) {
            $result = Db::getInstance()->executeS("SELECT `quantity` FROM `" . _DB_PREFIX_ . "product` WHERE `id_product` = '" . $product_id . "'");
            if (isset($result) && count($result)) {
                $quantity = $result['0']['quantity'];
            } else {
                $quantity = 0;
            }
        }
        return $quantity;
    }

    public function getCedTraderaAttribute($product_id, $profile_info, $product)
    {
        $db = Db::getInstance();
        $profile_info = $profile_info['0'];
        if ($product_id && isset($profile_info['profile_attribute_mapping']) && $profile_info['profile_attribute_mapping']) {
            $profile_attribute_mappings = Tools::jsonDecode($profile_info['profile_attribute_mapping'], true);

            $attribute_traderas = array();
            if ($profile_attribute_mappings) {
                foreach ($profile_attribute_mappings as $profile_attribute_mapping)
                {
                    $attribute_tradera = array();
                  if(isset($profile_attribute_mapping['store_attribute']) && $profile_attribute_mapping['store_attribute'])
                  {
                    $type_array = explode('-', $profile_attribute_mapping['store_attribute']);
                    if(isset($type_array['0']) && ($type_array['0']=='option')) {
                      $options = array();
                      if(isset($profile_attribute_mapping['option']))
                      $options = array_filter($profile_attribute_mapping['option']);
                      $option_value = $this->getProductOptions($product_id, $type_array['1'],$profile_info['profile_language'],$options);
                      
                      $attribute_tradera = array(
                        'attributes_id' =>(int) $profile_attribute_mapping['tradera_attribute'], 
                        'value' => $option_value
                        );
                    } else if(isset($type_array['0']) && ($type_array['0']=='attribute')) 
                    {
                       $attribute_value = $this->getProductAttributes($product_id, $type_array['1'],$profile_info['profile_language']);
                       $attribute_tradera = array(
                        'attributes_id' =>(int) $profile_attribute_mapping['tradera_attribute'],
                         'value' => $attribute_value
                         );
                    } else if(isset($type_array['0']) && ($type_array['0']=='product')) 
                    {
                         $attribute_tradera = array(
                            'attributes_id' =>(int) $profile_attribute_mapping['tradera_attribute'],
                          'value' => $product[$type_array['1']]
                          );
                    } else 
                    {
                        if(!empty($profile_attribute_mapping['tradera_attribute']) && !empty($profile_attribute_mapping['store_attribute'])) {
                            $attribute_tradera = array(
                             'attributes_id' =>(int) $profile_attribute_mapping['tradera_attribute'],
                             'value' => $profile_attribute_mapping['store_attribute']
                             );
                        }
                    }
                  } else if(isset($profile_attribute_mapping['default_values']) && $profile_attribute_mapping['default_values'])
                  {
                     $attribute_tradera = array(
                        'attributes_id' =>(int) $profile_attribute_mapping['tradera_attribute'], 
                        'value' => $profile_attribute_mapping['default_values']
                        );
                  }
                  
                  if(isset($attribute_tradera['value']) && !$attribute_tradera['value'])
                  {
                    if(isset($profile_attribute_mapping['default_values']) && $profile_attribute_mapping['default_values']){
                      $attribute_tradera = array(
                        'attributes_id' =>(int) $profile_attribute_mapping['tradera_attribute'], 
                        'value' => $profile_attribute_mapping['default_values']);
                    }
                  }
                  $product_d = $db->executeS("SELECT * FROM `". _DB_PREFIX_ ."cedtradera_uploaded_products` WHERE product_id = ".(int)$product_id);
                  if(!empty($product_d) && $product_d['0']['product_attribute'])
                  {
                      $product_attribute_d = Tools::jsonDecode($product_d['0']['product_attribute'], true);
                  }
                  
                  $shoppee_selected_option = false;

                  $attributes_id = isset($attribute_tradera['attributes_id']) ? $attribute_tradera['attributes_id'] : '0';
                    if (isset($product_attribute_d[$attributes_id]) && isset($product_attribute_d[$attributes_id]['tradera_attribute']) && isset($product_attribute_d[$attributes_id]['default_values']) && $product_attribute_d[$attributes_id]['default_values']) {
                        $attribute_tradera['value'] = $product_attribute_d[$attribute_tradera['attributes_id']]['default_values'];
                      }

                  $attribute_traderas[] = $attribute_tradera;
                }
                $attribute_traderas = array_filter($attribute_traderas);
                return $attribute_traderas;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function getProductOptions($product_id, $store_attribute, $language_id, $attribute_tradera) 
    {
        $product_option_data = '';

        if($store_attribute) {
            if (is_numeric($store_attribute) && !empty($store_attribute)) {
                if (isset($attribute_tradera))   {
                    foreach ($attribute_tradera as $option_values) {

                        $product_option_value_query = Db::getInstance()->executeS("SELECT al.`id_attribute` AS option_value_id, al.`name`, a.`position` AS sort_order FROM `"._DB_PREFIX_."attribute` AS a LEFT JOIN `"._DB_PREFIX_."attribute_lang` AS al ON (al.id_attribute = a.id_attribute) WHERE al.`id_attribute` = '". (int)$option_values['store_attribute_id'] ."' AND al.`id_lang` = '". (int)$language_id ."' AND a.`id_attribute_group` = '". (int)$store_attribute ."' ");
 
                        if(count($product_option_value_query) && isset($option_values['tradera_attribute']) && $option_values['tradera_attribute']) {
                            $product_option_data = $option_values['tradera_attribute'];
                            break;
                        }
                    }
                }
            } 
        }
        return $product_option_data;
    }

    public function getProductAttributes($product_id, $store_attribute,$language_id)
    {
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        $product_attribute_data = '';

        if($product_id && $store_attribute) {
            $product_attribute_query = Feature::getFeature($default_lang, $store_attribute);
            if(isset($product_attribute_query) && count($product_attribute_query) && isset($product_attribute_query['name']) && $product_attribute_query['name']) {
                    $product_attribute_data = $product_attribute_query['name'];
            }
        }
        return $product_attribute_data;
    }

    public function isVariantProduct($product_id, $default_lang) 
    {
        $db = Db::getInstance();
        $productObject = new Product($product_id, false, $default_lang);
        $variants = $productObject->getAttributeCombinations($default_lang);
        if(isset($variants) && !empty($variants)) {
            return $variants;
        } else {
            return array();
        }
        
    }

    public function validateProduct($productToUpload, $category)
    {
       if(isset($productToUpload['attributes'])) 
       {
           $required_attribute = array();
           $product_attribute = array();
           $Required_product_attribute = array();
           $result = Db::getInstance()->executeS("SELECT attribute_id,attribute_name FROM `". _DB_PREFIX_ ."cedtradera_attribute` WHERE category_id='".$category."' AND is_mandatory='1'");
           
           if(isset($result) && count($result)) {
               foreach ($result as  $row) {
                   $required_attribute[] =  $row['attribute_id'];
                   $Required_product_attribute[$row['attribute_id']] = $row['attribute_name'];
               }
           }

           foreach($productToUpload['attributes'] as $attribute) {
                 $product_attribute[] =  $attribute['attributes_id'];
           }
           $product_attribute = array_unique($product_attribute);
           $array_not_found = array_diff($required_attribute,$product_attribute);
           if(!empty($array_not_found)) {
               $name='';
               foreach ($array_not_found as $attribute_id) {
                   if(isset($Required_product_attribute[$attribute_id]))
                   $name .= $Required_product_attribute[$attribute_id] . ',';
               }
               $name = rtrim($name, ',');
               return array('success' => false, 'message' =>$name);
           }
       }
        return array('success' => true, 'message' =>$productToUpload);
    }

    public function getCedTraderaAttributeType($product_id, $profile_id)
    {
        $result = Db::getInstance()->getValue("SELECT tradera_item_id FROM `". _DB_PREFIX_ ."cedtradera_uploaded_products` WHERE product_id='".$product_id."' AND tradera_profile_id = '". $profile_id ."'");
        if(!empty($result)){
            return '2';
        } else {
            return '1';
        }
    }

    public function getTraderaItemId($product_id=0) 
    {
        $db = Db::getInstance();
        if ($product_id) {
            // $sql = "DELETE FROM `". _DB_PREFIX_ ."cedshopee_uploaded_products` where tradera_item_id = 0";
            // $db->delete(
            //     'cedshopee_uploaded_products',
            //     'tradera_item_id = 0'
            //     );
            $tradera_item_id = '';
            $sql = "SELECT `tradera_item_id` FROM `". _DB_PREFIX_ ."cedtradera_uploaded_products` WHERE `product_id`='".$product_id."' AND tradera_item_id > 0";
            $result = $db->executeS($sql);
            if ($result && count($result) && isset($result['0']['tradera_item_id'])) {
                $tradera_item_id = $result['0']['tradera_item_id'];
            }
            return $tradera_item_id;
        }
        return false;
    }
}