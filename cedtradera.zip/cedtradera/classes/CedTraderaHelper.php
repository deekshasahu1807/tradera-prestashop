<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedTradera
 */

class CedTraderaHelper
{
    // public function traderaGetRequest($postRequest, $callRequest, $body)
    // {
    //     $this->app_id = Configuration::get('CEDTRADERA_APP_ID');
    //     $this->app_key = Configuration::get('CEDTRADERA_APP_KEY');
    //     $this->user_id = '4843208';
    //     $this->sec_key = Configuration::get('CEDTRADERA_SECRET_KEY');
    //     $this->api_v = 'v3';
    //     try {
    //         $publicServiceUrl = 'https://api.tradera.com/'.$this->api_v.'/PublicService.asmx';
    //         $publicServiceUrlWithAuth = $publicServiceUrl
    //                         . '?appId=' . $this->app_id
    //                         . '&appKey=' . $this->app_key;

    //         $publicClient = new SoapClient(
    //             $publicServiceUrl . '?WSDL',
    //             array('location' => $publicServiceUrlWithAuth)
    //         );

    //         // Parameters for call to FetchToken
    //         $fetchTokenParams = new StdClass();
    //         $fetchTokenParams -> userId = $this->user_id;
    //         $fetchTokenParams -> secretKey = $this->sec_key;
    //         // Make SOAP call
    //         $fetchTokenResponse = $publicClient -> FetchToken($fetchTokenParams);
    //         echo '<pre>'; var_dump($fetchTokenResponse); print_r($fetchTokenResponse); die;
    //         // Handle result
    //         return array(
    //             'token'   => isset($fetchTokenResponse->FetchTokenResult->AuthToken) ? $fetchTokenResponse->FetchTokenResult->AuthToken : null,
    //             'expires' => isset($fetchTokenResponse->FetchTokenResult->HardExpirationTime) ? $fetchTokenResponse->FetchTokenResult->HardExpirationTime : null,
    //             'error'   => null,
    //         );
    //     }
    //     catch(SoapFault $soapFault) {
    //         return array(
    //             'token'   => null,
    //             'expires' => null,
    //             'error'   => $soapFault->faultstring,
    //         );
    //     }
    // }

    public function __construct() 
    {
        $this->api_url = Configuration::get('CEDTRADERA_API_URL');
        $this->userId = Configuration::get('CEDTRADERA_USER_ID');
        $this->secretKey = Configuration::get('CEDTRADERA_SECRET_KEY');
        $this->appId = Configuration::get('CEDTRADERA_APP_ID');
        $this->appKey = Configuration::get('CEDTRADERA_APP_KEY');
        $this->token = Configuration::get('CEDTRADERA_API_ACCESS_TOKEN');    
    }
    
    public function fetchToken()
    {

        try {
            $publicServiceUrl = 'https://api.tradera.com/v3/PublicService.asmx';

            $publicServiceUrlWithAuth = $publicServiceUrl
                            . '?appId=' . $this->appId
                            . '&appKey=' . $this->appKey;

            $publicClient = new SoapClient(
                $publicServiceUrl . '?WSDL',
                array('location' => $publicServiceUrlWithAuth)
            );

            // Parameters for call to FetchToken
            $fetchTokenParams = new StdClass();
            $fetchTokenParams->userId = $this->userId;
            $fetchTokenParams->secretKey = $this->secretKey;
            echo "<pre>";print_r($fetchTokenParams);die;
            // Make SOAP call
            $fetchTokenResponse = $publicClient->FetchToken($fetchTokenParams);
            // echo "<pre>";print_r($fetchTokenResponse);die;
            // Handle result
            return array(
                'token'   => isset($fetchTokenResponse->FetchTokenResult->AuthToken) ? $fetchTokenResponse->FetchTokenResult->AuthToken : null,
                'expires' => isset($fetchTokenResponse->FetchTokenResult->HardExpirationTime) ? $fetchTokenResponse->FetchTokenResult->HardExpirationTime : null,
                'error'   => null,
            );
        }
        catch(SoapFault $soapFault) {
            return array(
                'token'   => null,
                'expires' => null,
                'error'   => $soapFault->faultstring,
            );
        }
    }

    public function getCategories() 
    {
        try {
            $publicServiceUrl = 'https://api.tradera.com/v3/PublicService.asmx';
            $publicServiceUrlWithAuth = $publicServiceUrl
                            . '?appId=' . $this->appId
                            . '&appKey=' . $this->appKey;

            $publicClient = new SoapClient(
                $publicServiceUrl . '?WSDL',
                array('location' => $publicServiceUrlWithAuth)
            );

            // Make SOAP call
            $fetchTokenResponse = $publicClient -> GetCategories();
            // Handle result
            return array(
                'result'   => isset($fetchTokenResponse->GetCategoriesResult) ? $fetchTokenResponse->GetCategoriesResult : null,
                'error'   => null,
            );
        }
        catch(SoapFault $soapFault) {
            return array(
                'result'   => null,
                'error'   => $soapFault->faultstring,
            );
        }
    }

    public function addShopItem($product_data)
    {
        try {
            $restrictedServiceUrl = 'https://api.tradera.com/v3/RestrictedService.asmx';

            $restrictedServiceUrlWithAuth = $restrictedServiceUrl
                            . '?appId=1822'
                            . '&appKey=4e54e9e8-5124-46e2-a183-eb868b2ada19'
                            . '&userId=4274027'
                            . '&token=f89b4470-299e-464a-91a2-648dc3b3cacd';

            $restrictedClient = new SoapClient(
                $restrictedServiceUrl . '?WSDL',
                array('location' => $restrictedServiceUrlWithAuth,"stream_context" => stream_context_create(
                    array(
                        'ssl' => array(
                            'verify_peer'       => false,
                            'verify_peer_name'  => false,
                        )
                    )
                ))
            );

            $title = $product_data['title'];
            $description = $product_data['description'];
            $quantity = $product_data['quantity'];
            $price = (int)$product_data['price'];
            $vat = $product_data['vat'];

            $itemImages = array();
            foreach ($product_data['images'] as $key => $itemImageName) {
                $itemImageData = new StdClass();
                $itemImageData -> Format = $itemImageName['format'];
                $itemImageData -> Data = $itemImageName['data'];
                $itemImageData -> Name = explode('.', $itemImageName['name'])[0];
                $itemImageData -> HasMega = true;
                array_push($itemImages, $itemImageData);
            }
            
            $shippingOptionPosten = new StdClass();
            $shippingOptionPosten -> ShippingOptionId = $product_data['shipping_id'];
            $shippingOptionPosten -> Cost = $product_data['shipping_cost'];
            $shippingOptionPickup = new StdClass();
            $shippingOptionPickup -> ShippingOptionId = $product_data['shipping_id'];
            $shippingOptionPickup -> Cost = $product_data['shipping_cost'];
            $myShippingOptions = array($shippingOptionPosten, $shippingOptionPickup);

            $paymentOptionCashOnPickup = 32;
            $paymentOptionKlarna = 8192;
            $myPaymentOptions = array($paymentOptionCashOnPickup, $paymentOptionKlarna);

            $myShippingConditions = 'Shipping conditions';
            $myPaymentConditions = 'Payment conditions';

            $shopItem = new StdClass();
            $shopItem -> Title = $title;
            $shopItem -> Description = $description;
            $shopItem -> CategoryId = $product_data['category_id'];
            $shopItem -> AcceptedBuyerId = 3; //international
            $shopItem -> ShippingOptions = $myShippingOptions;
            $shopItem -> PaymentOptionIds = $myPaymentOptions;
            $shopItem -> ItemAttributes = 1; // 1=New, 2= Used
            $shopItem -> ShippingCondition = $myShippingConditions;
            $shopItem -> PaymentConditions = $myPaymentConditions;
            $shopItem -> OwnReferences = $product_data['reference']; // Array of strings
            $shopItem -> VAT = $vat; //
            $shopItem -> ItemImages = '';//$itemImages;

            // $time = $product_data['activate_date'];
            // echo date('Y-m-d H:i:s', $time); die;
            // $hour=date("H",$time);
            // $min=date("i",$time);
            // $sec=date("s",$time);
            // $month=date("m",$time);
            // $day=date("d",$time);
            // $year=date("Y",$time);

            $shopItem ->ActivateDate = $product_data['activate_date'];

            // $time = $product_data['deactivate_date'];
            // $hour=date("H",$time);
            // $min=date("i",$time);
            // $sec=date("s",$time);
            // $month=date("m",$time);
            // $day=date("d",$time);
            // $year=date("Y",$time);

            $shopItem -> DeactivateDate = $product_data['deactivate_date'];
            $shopItem -> Quantity = $quantity;
            $shopItem -> ExternalId = array(12,23,56,45); // Array of strings
            $shopItem -> Price = $price;

            // echo "<pre>";print_r($shopItem);die;
            $addShopItemParams = new StdClass();
            $addShopItemParams -> shopItemData = $shopItem;

            $addShopItemResult = $restrictedClient->AddShopItem($addShopItemParams);
            echo "<pre>";print_r($addShopItemResult);die;
            $requestId = $addShopItemResult -> AddShopItemResult ->  RequestId;
            $itemId    = $addShopItemResult -> AddShopItemResult ->  ItemId;
            
            return array(
                'id_tradera' => $itemId,
                'id_request' => $requestId,
                'error'      => null,
            );
        }
        catch(SoapFault $soapFault) {var_dump($soapFault);die;
            return array(
                'id_tradera' => null,
                'id_request' => null,
                'error'      => $soapFault->faultstring, 
            );
        }
    }

    public function traderaGetRequest($postRequest, $callRequest, $body)
    {
        try {
            $api_url = Configuration::get('CEDTRADERA_API_URL');
            $userId = Configuration::get('CEDTRADERA_APP_ID');
            $secretKey = Configuration::get('CEDTRADERA_SECRET_KEY');
            $appId = Configuration::get('CEDTRADERA_APP_ID');
            $appKey = Configuration::get('CEDTRADERA_APP_KEY');
            
            $token = Configuration::get('CEDTRADERA_API_ACCESS_TOKEN');

            $soap_request  = '<?xml version="1.0" encoding="utf-8"?>';
            $soap_request .= '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">';
            $soap_request .= '<soap:Header>';
            $soap_request .= '<AuthenticationHeader xmlns="http://api.tradera.com">';
            $soap_request .= '<AppId>';
            $soap_request .= (int)$appId;
            $soap_request .= '</AppId>';
            $soap_request .= '<AppKey>';
            $soap_request .= (string)$appKey;
            $soap_request .= '</AppKey>';
            $soap_request .= '</AuthenticationHeader>';
            if(!empty($userId) && !empty($token)) 
            {
                $soap_request .= '<AuthorizationHeader xmlns="http://api.tradera.com">';
                $soap_request .= '<UserId>';
                $soap_request .= $userId; // 77FA15BA-E13C-4D83-B6DC-E7F9FFB6601F
                $soap_request .= '</UserId>';
                $soap_request .= '<Token>';
                $soap_request .= $token;
                $soap_request .= '</Token>';
                $soap_request .= '</AuthenticationHeader>';
            }
            $soap_request .= '<ConfigurationHeader xmlns="http://api.tradera.com">';
            $soap_request .= '<Sandbox>1</Sandbox>';
            $soap_request .= '<MaxResultAge>25</MaxResultAge>';
            $soap_request .= '</ConfigurationHeader>';
            $soap_request .= '</soap:Header>';
            $soap_request .= $body;
            $soap_request .= '</soap:Envelope>';

            $header = array();
            
            $header[] = "POST ". $postRequest ." HTTP/1.1";
            $header[] = "Host: api.tradera.com";
            $header[] = "Content-Type: application/xml;charset=\"utf-8\"";
            $header[] = "Content-Length: ".strlen($soap_request);
            $header[] = "SOAPAction: " . $api_url . '/' . $callRequest;

            $path = $postRequest . '/' . $callRequest;
            $url = $api_url . $path;
            // $url = 'https://api.tradera.com/tokenlogin.aspx?appId=1815&pkey=b4dbd86d-bbe9-4e5f-a131-e1b9f4b11751&skey=77FA15BA-E13C-4D83-B6DC-E7F9FFB6601F';
            // 'https://api.tradera.com/tokenlogin.aspx' 
             // echo '<pre>'; print_r($url); die;
              $soap_do = curl_init();
              curl_setopt($soap_do, CURLOPT_URL, $url);
              curl_setopt($soap_do, CURLOPT_CONNECTTIMEOUT, 10);
              curl_setopt($soap_do, CURLOPT_TIMEOUT, 10);
              curl_setopt($soap_do, CURLOPT_RETURNTRANSFER, true );
              curl_setopt($soap_do, CURLOPT_SSL_VERIFYPEER, false);
              curl_setopt($soap_do, CURLOPT_SSL_VERIFYHOST, false);
              curl_setopt($soap_do, CURLOPT_POST,           true );
              curl_setopt($soap_do, CURLOPT_POSTFIELDS,     $soap_request);
              curl_setopt($soap_do, CURLOPT_HTTPHEADER,     $header);
              $server_output = curl_exec($soap_do);

                $curlError = curl_error($soap_do);

                $header_size = curl_getinfo($soap_do, CURLINFO_HEADER_SIZE);
                $body = Tools::substr($server_output, $header_size);
                
                $res = array(
                    'Post Request Url' => $url,
                    'Post Request Header' => $header,
                    'Post Request Params' => $soap_request,
                    'Post Request Response' => $server_output,
                );
                $this->log(__METHOD__, 'Info', 'Post Request to tradera', Tools::jsonEncode($res));
                // $response = $this->xml2array($body);
                $response = new \SimpleXMLElement($body);
                $response = json_decode(json_encode($response), true);
            // echo '<pre>'; print_r($response); die;
                if (!curl_errno($soap_do)) {
                    $http_code = curl_getinfo($soap_do, CURLINFO_HTTP_CODE);
                    $http_code = 200;
                    if ($http_code == 200) {
                        return array('success' => true, 'message' => $response);
                    } else {
                        return array('success' => false, 'message' => $response);
                    }
                }
                curl_close($ch);
              // if(curl_exec($soap_do) === false) {
              //   $err = 'Curl error: ' . curl_error($soap_do);
              //   curl_close($soap_do);
              //   print $err;
              // } else {
              //   curl_close($soap_do);
              //   print 'Operation completed without any errors';
              // }
        } catch(Exception $e){
            $this->log(
                __METHOD__,
                'Info',
                'Get Token Request',
                Tools::jsonEncode(
                    array(
                        'Url' => $url,
                        'Request Param' => $header,
                        'Response' => $server_output
                    )
                )
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function traderaGetRequest45($callRequest)
    {
        try {
            $path = '/v3/PublicService.asmx/' . $callRequest;
            $api_url = Configuration::get('CEDTRADERA_API_URL');
            $app_id = Configuration::get('CEDTRADERA_APP_ID');
            $app_key = Configuration::get('CEDTRADERA_APP_KEY');
            $secret_key = Configuration::get('CEDTRADERA_SECRET_KEY');
            $accept_url = Configuration::get('CEDTRADERA_ACCEPT_URL');
            $reject_url = Configuration::get('CEDTRADERA_REJECT_URL');
            if (empty($api_url) || empty($app_id)
                || empty($app_key) || empty($secret_key)
            ) {
                return array(
                    'success' => false,
                    'message' => "Invalid Api credentials"
                );
            }
            $url = $api_url . $path . '?';
            $params = array(
                'appId' => trim($app_id),
                'appKey' => trim($app_key),
                'userId' => trim($app_id),
                'secretKey' => trim($secret_key)
            );
            if(isset($params) && is_array($params) && !empty($params)) {
                $url .= http_build_query($params);
            }

            $headers = array();
            $headers[] = "Host: api.tradera.com";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $server_output = curl_exec($ch);

            $res = array(
                'Get Request Url' => $url,
                'Get Request Header' => $headers,
                'Get Request Parameters' => $params,
                'Get Request Response' => $server_output,
            );
            $this->log(__METHOD__, 'Info', 'Tradera Get Request', Tools::jsonEncode($res));

            $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $header = Tools::substr($server_output, 0, $header_size);
            $body = Tools::substr($server_output, $header_size);
            if (!curl_errno($ch)) {
                $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                if ($http_code == 200) {
                    $xml_response = $this->xml2array($server_output);
                    
                    return array('success' => true, 'response' => $xml_response);
                } else {
                    if ($body) {
                        return array('success' => false, 'message' => $body);
                    } else {
                        return array('success' => false, 'message' => $server_output);
                    }
                }
            }
            curl_close($ch);
        } catch (Exception $e) {
            $this->log(
                __METHOD__,
                'Info',
                'Get Token Request',
                Tools::jsonEncode(
                    array(
                        'Url' => $url,
                        'Request Param' => $params,
                        'Response' => $response
                    )
                )
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function traderaPostRequest($postRequest, $callRequest, $body)
    {
        try{
            $api_url = Configuration::get('CEDTRADERA_API_URL');
            $userId = '4274027';
            $secretKey = Configuration::get('CEDTRADERA_SECRET_KEY');
            $appId = Configuration::get('CEDTRADERA_APP_ID');
            $appKey = Configuration::get('CEDTRADERA_APP_KEY');
            $token = Configuration::get('CEDTRADERA_API_ACCESS_TOKEN');

            $soap_request  = '<?xml version="1.0" encoding="utf-8"?>';
            $soap_request .= '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">';
            $soap_request .= '<soap:Header>';
            $soap_request .= '<AuthenticationHeader xmlns="http://api.tradera.com">';
            $soap_request .= '<AppId>';
            $soap_request .= $appId;
            $soap_request .= '</AppId>';
            $soap_request .= '<AppKey>';
            $soap_request .= $appKey;
            $soap_request .= '</AppKey>';
            $soap_request .= '</AuthenticationHeader>';
            if(!empty($userId) && !empty($token)) 
            {
                $soap_request .= '<AuthorizationHeader xmlns="http://api.tradera.com">';
                $soap_request .= '<UserId>';
                $soap_request .= $userId;
                $soap_request .= '</UserId>';
                $soap_request .= '<Token>';
                $soap_request .= $token;
                $soap_request .= '</Token>';
                $soap_request .= '</AuthenticationHeader>';
            }
            $soap_request .= '<ConfigurationHeader xmlns="http://api.tradera.com">';
            $soap_request .= '<Sandbox>1</Sandbox>';
            $soap_request .= '<MaxResultAge>25</MaxResultAge>';
            $soap_request .= '</ConfigurationHeader>';
            $soap_request .= '</soap:Header>';
            $soap_request .= $body;
            $soap_request .= '</soap:Envelope>';

            $header = array();

            $header[] = "POST ". $postRequest ." HTTP/1.1";
            $header[] = "Host: api.tradera.com";
            $header[] = "Content-type: application/xml;charset=\"utf-8\"";
            $header[] = "Content-Length: ".strlen($soap_request);
            $header[] = "SOAPAction: " . $api_url . '/' . $callRequest;
            
            $path = $postRequest . '/' . $callRequest;
            $url = $api_url . $path;
             // echo '<pre>'; print_r($url); die;
              $soap_do = curl_init();
              curl_setopt($soap_do, CURLOPT_URL, $url );
              curl_setopt($soap_do, CURLOPT_CONNECTTIMEOUT, 10);
              curl_setopt($soap_do, CURLOPT_TIMEOUT,        10);
              curl_setopt($soap_do, CURLOPT_RETURNTRANSFER, true );
              curl_setopt($soap_do, CURLOPT_SSL_VERIFYPEER, false);
              curl_setopt($soap_do, CURLOPT_SSL_VERIFYHOST, false);
              curl_setopt($soap_do, CURLOPT_POST,           true );
              curl_setopt($soap_do, CURLOPT_POSTFIELDS,     $soap_request);
              curl_setopt($soap_do, CURLOPT_HTTPHEADER,     $header);
                $server_output = curl_exec($soap_do);
              
                

                $curlError = curl_error($soap_do);

                $header_size = curl_getinfo($soap_do, CURLINFO_HEADER_SIZE);

                $body = Tools::substr($server_output, $header_size);
                
                $res = array(
                    'Post Request Url' => $url,
                    'Post Request Header' => $header,
                    'Post Request Params' => $soap_request,
                    'Post Request Response' => $server_output,
                );
                $this->log(__METHOD__, 'Info', 'Post Request to tradera', Tools::jsonEncode($res));
                // $response = $this->xml2array($server_output);
                $response = new \SimpleXMLElement($body);
                $response = json_decode(json_encode($response), true);
                // echo '<pre>'; print_r($response); die;
                if (!curl_errno($soap_do)) {
                    $http_code = curl_getinfo($soap_do, CURLINFO_HTTP_CODE);
                    $http_code = 200;
                    if ($http_code == 200) {
                        $response = $response['soap:Envelope']['soap:Body'];
                        return array('success' => true, 'message' => $response);
                    } else {
                        return array('success' => false, 'message' => $response);
                    }
                }
                curl_close($ch);
             
              // if(curl_exec($soap_do) === false) {
              //   $err = 'Curl error: ' . curl_error($soap_do);
              //   return array('success' => false, 'response' => $err);
              //   curl_close($soap_do);
              //   print $err;
              // } else {
              //   return array('success' => true, 'response' => $server_output);
              //   curl_close($soap_do);
              //   print 'Operation completed without any errors';
              // }

        } catch (Exception $e) {
            $this->log(
                'CedTradeaHelper::traderaPostRequest',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function traderaPostRequest123($callRequest)
    {
        try {
            $path = '/v3/PublicService.asmx/' . $callRequest;
            $api_url = Configuration::get('CEDTRADERA_API_URL');
            $app_id = Configuration::get('CEDTRADERA_APP_ID');
            $app_key = Configuration::get('CEDTRADERA_APP_KEY');
            $secret_key = Configuration::get('CEDTRADERA_SECRET_KEY');
            $accept_url = Configuration::get('CEDTRADERA_ACCEPT_URL');
            $reject_url = Configuration::get('CEDTRADERA_REJECT_URL');
            if (empty($api_url) || empty($app_id)
                || empty($app_key) || empty($secret_key)
            ) {
                return array(
                    'success' => false,
                    'message' => "Invalid Api credentials"
                );
            }
            $url = $api_url . $path . '?';

            $params = array(
                'appId' => trim($app_id),
                'appKey' => trim($app_key),
                'userId' => trim($app_id),
                'secretKey' => trim($secret_key)
            );
            
            // echo '<pre>'; print_r($url); die;
            $body = array();
            
            if(isset($params) && is_array($params) && !empty($params)) {
                $body = http_build_query($params);
            }
            // echo '<pre>'; print_r($body); die;
            $headers = array();

            $headers['Content-Type'] = "application/x-www-form-urlencoded";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_HEADER, 1);

            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            //curl_setopt($ch, CURLOPT_USERPWD, $this->user . ":" . $this->pass);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $server_output = curl_exec($ch);
            $curlError = curl_error($ch);
            $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $body = Tools::substr($server_output, $header_size);
            
            $res = array(
                'Post Request Url' => $url,
                'Post Request Header' => $headers,
                'Post Request Params' => $params,
                'Post Request Response' => $server_output,
            );
            $this->log(__METHOD__, 'Info', 'Post Request to Tradera', Tools::jsonEncode($res));
            if ($curlError) {
                return array('success' => false, 'message' => $curlError);
            }
            if (!curl_errno($ch)) {
                $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                if ($http_code == 200) {
                    return array('success' => true, 'response' => $body);
                } else {
                    return array('success' => false, 'message' => $body);
                }
            }
            curl_close($ch);
        } catch (Exception $e) {
            $this->log(
                'CedTradeaHelper::traderaPostRequest',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function xml2array($contents, $get_attributes = 1, $priority = 'tag')
    {
        if (!$contents) {
            return array();
        }
        if (is_array($contents)) {
            return array();
        }
        if (!function_exists('xml_parser_create')) {
            // print "'xml_parser_create()' function not found!";
            return array();
        }
        // Get the XML parser of PHP - PHP must have this module for the parser to work
        $parser = xml_parser_create('');
        xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, "UTF-8"); // http://minutillo.com/steve/weblog/2004/6/17/php-xml-and-character-encodings-a-tale-of-sadness-rage-and-data-loss
        xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
        xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
        xml_parse_into_struct($parser, trim($contents), $xml_values);
        xml_parser_free($parser);
        if (!$xml_values) {
            return; //Hmm...
        }
        // Initializations
        $xml_array = array();
        //        $parents = array();
        //        $opened_tags = array();
        //        $arr = array();
        $current = &$xml_array; //Refference
        // Go through the tags.
        $repeated_tag_index = array(); //Multiple tags with same name will be turned into an array
        $attributes = array();
        $value = array();
        $parent = array();
        $type = '';
        $level = '';
        $tag = '';
        foreach ($xml_values as $data) {
            unset($attributes, $value); //Remove existing values, or there will be trouble
            // This command will extract these variables into the foreach scope
            // tag(string), type(string), level(int), attributes(array).
            extract($data); //We could use the array by itself, but this cooler.
            $result = array();
            $attributes_data = array();
            if (isset($value)) {
                if ($priority == 'tag') {
                    $result = $value;
                } else {
                    $result['value'] = $value; //Put the value in a assoc array if we are in the 'Attribute' mode
                }
            }
            // Set the attributes too.
            if (isset($attributes) and $get_attributes) {
                foreach ($attributes as $attr => $val) {
                    if ($attr == 'ResStatus') {
                        $current[$attr][] = $val;
                    }
                    if ($priority == 'tag') {
                        $attributes_data[$attr] = $val;
                    } else {
                        $result['attr'][$attr] = $val; //Set all the attributes in a array called 'attr'
                    }
                }
            }
            // See tag status and do the needed.
            //echo"<br/> Type:".$type;
            if ($type == "open") { //The starting of the tag '<tag>'
                $parent[$level - 1] = &$current;
                if (!is_array($current) or (!in_array($tag, array_keys($current)))) { //Insert New tag
                    $current[$tag] = $result;
                    if ($attributes_data) {
                        $current[$tag . '_attr'] = $attributes_data;
                    }
                    $repeated_tag_index[$tag . '_' . $level] = 1;
                    $current = &$current[$tag];
                } else { //There was another element with the same tag name
                    if (isset($current[$tag][0])) { //If there is a 0th element it is already an array
                        $current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
                        $repeated_tag_index[$tag . '_' . $level]++;
                    } else { //This section will make the value an array if multiple tags with
                        // the same name appear together
                        $current[$tag] = array(
                            $current[$tag],
                            $result
                        ); //This will combine the existing item and the new item together to make an array
                        $repeated_tag_index[$tag . '_' . $level] = 2;
                        if (isset($current[$tag . '_attr'])) { //The attribute of the last(0th)
                            // tag must be moved as well
                            $current[$tag]['0_attr'] = $current[$tag . '_attr'];
                            unset($current[$tag . '_attr']);
                        }
                    }
                    $last_item_index = $repeated_tag_index[$tag . '_' . $level] - 1;
                    $current = &$current[$tag][$last_item_index];
                }
            } elseif ($type == "complete") { //Tags that ends in 1 line '<tag />'
                // See if the key is already taken.
                if (!isset($current[$tag])) { //New Key
                    $current[$tag] = $result;
                    $repeated_tag_index[$tag . '_' . $level] = 1;
                    if ($priority == 'tag' and $attributes_data) {
                        $current[$tag . '_attr'] = $attributes_data;
                    }
                } else { //If taken, put all things inside a list(array)
                    if (isset($current[$tag][0]) and is_array($current[$tag])) { //If it is already an array...
                        // ...push the new element into that array.
                        $current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
                        if ($priority == 'tag' and $get_attributes and $attributes_data) {
                            $current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
                        }
                        $repeated_tag_index[$tag . '_' . $level]++;
                    } else { //If it is not an array...
                        $current[$tag] = array(
                            $current[$tag],
                            $result
                        ); //...Make it an array using using the existing value and the new value
                        $repeated_tag_index[$tag . '_' . $level] = 1;
                        if ($priority == 'tag' and $get_attributes) {
                            if (isset($current[$tag . '_attr'])) { //The attribute of the last(0th)
                                // tag must be moved as well
                                $current[$tag]['0_attr'] = $current[$tag . '_attr'];
                                unset($current[$tag . '_attr']);
                            }
                            if ($attributes_data) {
                                $current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
                            }
                        }
                        $repeated_tag_index[$tag . '_' . $level]++; //0 and 1 index is already taken
                    }
                }
            } elseif ($type == 'close') { //End of tag '</tag>'
                $current = &$parent[$level - 1];
            }
        }
        return ($xml_array);
    }

    public function log($method = '', $type = '', $message = '', $response = '', $force_log = false)
    {
        if (Configuration::get('CEDTRADERA_DEBUG_MODE') || $force_log == true) {
            $db = Db::getInstance();
            $db->insert(
                'cedtradera_logs',
                array(
                    'method' => pSQL($method),
                    'type' => pSQL($type),
                    'message' => pSQL($message),
                    'data' => pSQL($response, true),
                )
            );
        }
    }

    public static function getTraderaAttributes()
    {
        $db = Db::getInstance();
        $sql = "SELECT `attribute_id`,`attribute_name` FROM `" . _DB_PREFIX_ . "cedtradera_attribute` ";
        $result = $db->ExecuteS($sql);
        if (is_array($result) && count($result)) {
            return $result;
        } else {
            return array();
        }
    }

    public static function getDefaultTraderaAttributes()
    {
        return array(
            'OwnReferences' => array(
                'code' => 'OwnReferences',
                'title' => 'Item Sku',
                'description' => 'Reference of Product',
                'required' => true
            ),
           'Title' => array(
               'code' => 'Title',
               'title' => 'Title',
               'description' => 'Title of the Product',
               'required' => true
            ),
            'Description' => array(
                'code' => 'Description',
                'title' => 'Description',
                'description' => 'Description of the Product',
                'required' => true
            ),
            'Price' => array(
                'code' => 'Price',
                'title' => 'Price',
                'description' => 'Price of the product',
                'required' => true
            ),
            'Quantity' => array(
               'code' => 'Quantity',
               'title' => 'Stock',
               'description' => 'Stock of the product.',
               'required' => true
            ),
            
            'VAT' => array(
                'code' => 'VAT',
                'title' => 'VAT Rate',
                'description' => 'Tax included in price',
                'required' => true
            ),
            'ActivateDate' => array(
                'code' => 'ActivateDate',
                'title' => 'Activate Date',
                'description' => 'Product Activate Date & Time',
                'required' => true
            ),
            'DeactivateDate' => array(
                'code' => 'DeactivateDate',
                'title' => 'Deactivate Date',
                'description' => 'Product Deactivate Date & Time',
                'required' => true
            )
        );
    }

    public static function getSystemAttributes()
    {
        return array(
            'reference' => 'Reference',
            'name' => 'Name',
            'description' => 'Description',
            'price' => 'Price',
            'quantity' => 'Quantity',
            'reference' => 'Reference',
            'id_tax_rules_group' => 'Tax Rules'
        );
    }

    public static function getTraderaCategories($data = array())
    {
        $db = Db::getInstance();
        if(isset($data) && !empty($data['filter_name']))
        {
            $sql = "SELECT `category_id`,`category_name` FROM `" . _DB_PREFIX_ . "cedtradera_category` WHERE `category_name` LIKE '%" . pSQL($data['filter_name']) . "%' ORDER BY `category_name`";
            $result = $db->ExecuteS($sql);
        } else {
            $sql = "SELECT `category_id` FROM `" . _DB_PREFIX_ . "cedtradera_category` ORDER BY `category_name`";
            $result = $db->ExecuteS($sql);
        } 
        //echo "<pre>";print_r($result);die;
        if (is_array($result) && count($result)) {
            return $result;
        } else {
            return array();
        }
    }

    public function productSecondaryImageURL($product_id = 0, $attribute_id = 0)
    {
        $db = Db::getInstance();
        if ($product_id) {
            //$productImages = array();
            $additionalAssets = array();
            $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

            $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'image` i LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il 
            ON (i.`id_image` = il.`id_image`)';

            if ($attribute_id) {
                $sql .= ' LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute_image` ai ON (i.`id_image` = ai.`id_image`)';
                $attribute_filter = ' AND ai.`id_product_attribute` = ' . (int)$attribute_id;
                $sql .= ' WHERE i.`id_product` = ' . (int)$product_id . ' AND 
                il.`id_lang` = ' . (int)$default_lang . $attribute_filter . ' ORDER BY i.`position` ASC';
            } else {
                $sql .= ' WHERE i.`id_product` = ' . (int)$product_id . ' AND 
                il.`id_lang` = ' . (int)$default_lang . ' ORDER BY i.`position` ASC';
            }

            $Execute = $db->ExecuteS($sql);
            $type = ImageType::getFormatedName('large');
            $product = new Product($product_id);
            $link = new Link;
            if (count($Execute) > 0) {
                //$count = 0;
//                foreach ($Execute as $key => $image) {
                foreach ($Execute as $image) {
                    $image_url = $link->getImageLink($product->link_rewrite[$default_lang], $image['id_image'], $type);
                    if (isset($image['cover']) && $image['cover']) {
                        $additionalAssets['mainImageUrl'] =
                            (Configuration::get('PS_SSL_ENABLED') ? 'https://' : 'http://') . $image_url;
                    } else {
                        $additionalAssets['productSecondaryImageURL'][] =
                            (Configuration::get('PS_SSL_ENABLED') ? 'https://' : 'http://') . $image_url;
                    }
                }
            }
            return $additionalAssets;
        }
    }
}