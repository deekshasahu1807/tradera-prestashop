<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedTradera
 */

$db =  Db::getInstance();
$sql_queries = array();

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."cedtradera_category` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `category_id` text NOT NULL DEFAULT '',
  `category_name`  text NOT NULL DEFAULT '',
   PRIMARY KEY  (`id`)
);";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."cedtradera_attribute` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `attribute_id` text NOT NULL DEFAULT '',
  `attribute_name`  text NOT NULL DEFAULT '',
  `category_id` text NOT NULL DEFAULT '',
   PRIMARY KEY  (`id`)
);";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."cedtradera_profile` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `store_category` longtext COLLATE utf8_unicode_ci NOT NULL,
  `tradera_categories` longtext COLLATE utf8_unicode_ci NOT NULL,
  `tradera_category` longtext COLLATE utf8_unicode_ci NOT NULL,
  `profile_attribute_mapping` longtext COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `logistics` longtext COLLATE utf8_unicode_ci NOT NULL,
  `wholesale` longtext COLLATE utf8_unicode_ci NOT NULL,
  `default_mapping` text COLLATE utf8_unicode_ci NOT NULL,
  `profile_store` text COLLATE utf8_unicode_ci NOT NULL,
  `product_manufacturer` text COLLATE utf8_unicode_ci NOT NULL,
  `profile_language` int(11) NOT NULL,
  `tradera_category_name` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ;";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedtradera_profile_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `tradera_profile_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `tradera_status` text COLLATE utf8_unicode_ci NOT NULL,
  `error_message` longtext COLLATE utf8_unicode_ci NOT NULL,
  `tradera_item_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ;";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."cedtradera_feeds` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `feed_id` text,
  `feed_type` text,
  `created_at` text,
  `status` text,
  `response` text,
  `skus` text,
   PRIMARY KEY  (`id`)
);";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."cedtradera_order` (
  `id` int(15) NOT NULL  AUTO_INCREMENT,
  `order_item_id` text NOT NULL,
  `tradera_order_id` text NOT NULL,
  `merchant_sku` text NOT NULL,
  `deliver_by` text NOT NULL,
  `prestashop_order_id` text NOT NULL,
  `order_data` longtext NOT NULL,
  `shipment_data` longtext NOT NULL,
  `status` text NOT NULL,
  `order_date` text NOT NULL,
   PRIMARY KEY (`id`)
);";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."cedtradera_order_error` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `merchant_sku` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tradera_order_id` text NOT NULL,
  `reason` text NOT NULL,
  `order_data` longtext NOT NULL,
  PRIMARY KEY (`id`)
);";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."cedtradera_products` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `product_id` int(15) NOT NULL,
  `tradera_product_id` text NOT NULL,
  `tradera_status` text NOT NULL,
  `error` text NOT NULL,
  PRIMARY KEY (`id`)
);";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."cedtradera_variant_products` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `product_id` int(15) NOT NULL,
  `id_product_attribute` int(15) NOT NULL,
  `tradera_parent_id` text NOT NULL,
  `tradera_variant_id` text NOT NULL,
  PRIMARY KEY (`id`)
);";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."cedtradera_logs` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `method` text NOT NULL,   
  `type` varchar(150) NOT NULL,
  `message` text NOT NULL,   
  `data` longtext NOT NULL,   
  `created_at` datetime default current_timestamp,   
 PRIMARY KEY (`id`) 
);";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedtradera_uploaded_products` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `product_id` int(11) NOT NULL,
          `tradera_profile_id` int(11) NOT NULL,
          `tradera_status` text COLLATE utf8_unicode_ci NOT NULL,
          `error_message` longtext COLLATE utf8_unicode_ci NOT NULL,
          `tradera_item_id` bigint(20) NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

foreach ($sql_queries as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}
